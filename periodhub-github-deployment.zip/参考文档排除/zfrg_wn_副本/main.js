// Main JavaScript file for period.health website
// Initialize all functionality when DOM is loaded

document.addEventListener('DOMContentLoaded', function() {
    console.log('period.health website loaded');
    
    // Initialize core functionality
    initializeNavigation();
    initializeSearchHandlers();
    initializeScrollAnimations();
    initializeNewsletterForm();
    
    // Page-specific initialization
    initializePageSpecificFeatures();
});

// Navigation functionality
function initializeNavigation() {
    const mobileMenuBtn = document.getElementById('mobile-menu-btn');
    const mobileMenu = document.getElementById('mobile-menu');
    
    if (mobileMenuBtn && mobileMenu) {
        mobileMenuBtn.addEventListener('click', function() {
            mobileMenu.classList.toggle('hidden');
        });
        
        // Close mobile menu when clicking outside
        document.addEventListener('click', function(event) {
            if (!mobileMenuBtn.contains(event.target) && !mobileMenu.contains(event.target)) {
                mobileMenu.classList.add('hidden');
            }
        });
        
        console.log('Navigation initialized');
    }
}

// Search functionality (for pages with search)
function initializeSearchHandlers() {
    const searchInputs = document.querySelectorAll('input[type="search"]');
    
    if (searchInputs.length === 0) {
        console.log('No search input found on this page to initialize handler.');
        return;
    }
    
    searchInputs.forEach(input => {
        input.addEventListener('input', handleSearch);
        input.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                performSearch(this.value);
            }
        });
    });
    
    console.log('Search handlers initialized');
}

function handleSearch(event) {
    const query = event.target.value.toLowerCase();
    const searchableItems = document.querySelectorAll('[data-searchable]');
    
    searchableItems.forEach(item => {
        const text = item.textContent.toLowerCase();
        const isVisible = text.includes(query) || query === '';
        item.style.display = isVisible ? 'block' : 'none';
    });
}

function performSearch(query) {
    // This would typically send to a search endpoint
    console.log('Performing search for:', query);
    // For demo purposes, just alert
    if (query.trim()) {
        alert(`搜索功能将在后续版本中实现。搜索词：${query}`);
    }
}

// Smooth scrolling animations and intersection observer
function initializeScrollAnimations() {
    // Create intersection observer for fade-in animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-fade-in');
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    // Observe elements with fade-in class
    const elementsToAnimate = document.querySelectorAll('.fade-in-on-scroll');
    elementsToAnimate.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(el);
    });
    
    // Smooth scroll for anchor links
    const anchorLinks = document.querySelectorAll('a[href^="#"]');
    anchorLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            const targetId = this.getAttribute('href');
            const targetElement = document.querySelector(targetId);
            
            if (targetElement) {
                e.preventDefault();
                targetElement.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
    
    console.log('Scroll animations initialized');
}

// Newsletter subscription form
function initializeNewsletterForm() {
    const newsletterForm = document.getElementById('newsletter-form');
    
    if (!newsletterForm) {
        console.log('No newsletter form section found on this page to initialize handler.');
        return;
    }
    
    newsletterForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const emailInput = this.querySelector('input[type="email"]');
        const email = emailInput.value;
        
        // Basic email validation
        if (!isValidEmail(email)) {
            showNotification('请输入有效的邮箱地址', 'error');
            return;
        }
        
        // Simulate newsletter subscription
        const submitBtn = this.querySelector('button[type="submit"]');
        const originalText = submitBtn.textContent;
        
        submitBtn.textContent = '订阅中...';
        submitBtn.disabled = true;
        
        // Simulate API call
        setTimeout(() => {
            submitBtn.textContent = '订阅成功！';
            emailInput.value = '';
            showNotification('订阅成功！我们会定期发送健康资讯到您的邮箱。', 'success');
            
            setTimeout(() => {
                submitBtn.textContent = originalText;
                submitBtn.disabled = false;
            }, 2000);
        }, 1500);
    });
    
    console.log('Newsletter form initialized');
}

// Utility function to validate email
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Show notification function
function showNotification(message, type = 'info') {
    // Remove any existing notifications
    const existingNotification = document.querySelector('.notification');
    if (existingNotification) {
        existingNotification.remove();
    }
    
    const notification = document.createElement('div');
    notification.className = `notification fixed top-4 right-4 z-50 p-4 rounded-lg shadow-lg max-w-sm transition-opacity duration-300 ${
        type === 'success' ? 'bg-green-500 text-white' : 
        type === 'error' ? 'bg-red-500 text-white' : 
        'bg-blue-500 text-white'
    }`;
    
    notification.innerHTML = `
        <div class="flex items-center justify-between">
            <span class="text-sm">${message}</span>
            <button class="ml-4 text-white hover:text-gray-200" onclick="this.parentElement.parentElement.remove()">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                </svg>
            </button>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (notification && notification.parentElement) {
            notification.style.opacity = '0';
            setTimeout(() => {
                if (notification && notification.parentElement) {
                    notification.remove();
                }
            }, 300);
        }
    }, 5000);
}

// Page-specific feature initialization
function initializePageSpecificFeatures() {
    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    
    switch (currentPage) {
        case 'index.html':
        case '':
            initializeHomePage();
            break;
        case 'interactive-solutions.html':
            initializeSymptomAssessment();
            break;
        case 'instant-solutions.html':
            initializeInstantSolutions();
            break;
        case 'regular-conditioning.html':
            initializeRegularConditioning();
            break;
        case 'pain-tracker.html':
            if (typeof initializePainTracker === 'function') {
                initializePainTracker();
            }
            break;
        case 'faq.html':
            initializeFAQ();
            break;
        default:
            // Default initialization for other pages
            initializeGeneralFeatures();
    }
}

// Homepage specific features
function initializeHomePage() {
    // Animate statistics or other homepage-specific elements
    const statsElements = document.querySelectorAll('.stat-number');
    
    const animateStats = (entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const target = parseInt(entry.target.dataset.target) || 100;
                animateNumber(entry.target, 0, target, 2000);
                observer.unobserve(entry.target);
            }
        });
    };
    
    const statsObserver = new IntersectionObserver(animateStats, { threshold: 0.5 });
    statsElements.forEach(stat => statsObserver.observe(stat));
}

// Animate number counting
function animateNumber(element, start, end, duration) {
    const increment = (end - start) / (duration / 16);
    let current = start;
    
    const timer = setInterval(() => {
        current += increment;
        if (current >= end) {
            current = end;
            clearInterval(timer);
        }
        element.textContent = Math.floor(current);
    }, 16);
}

// Symptom Assessment functionality (referenced from assessment-logic.js)
function initializeSymptomAssessment() {
    console.log('Initializing symptom assessment...');
    
    // Check if assessment logic is loaded
    if (typeof processAssessment !== 'function') {
        console.warn('Assessment logic not loaded. Make sure assessment-logic.js is included.');
        return;
    }
    
    const assessmentForm = document.getElementById('symptom-assessment-form');
    if (!assessmentForm) {
        console.log('No assessment form found on this page.');
        return;
    }
    
    assessmentForm.addEventListener('submit', function(e) {
        e.preventDefault();
        processAssessment();
    });
    
    // Initialize multi-step navigation if present
    initializeMultiStepForm();
}

// Multi-step form functionality
function initializeMultiStepForm() {
    const stepButtons = document.querySelectorAll('.step-btn');
    const nextButtons = document.querySelectorAll('.next-step');
    const prevButtons = document.querySelectorAll('.prev-step');
    
    stepButtons.forEach((btn, index) => {
        btn.addEventListener('click', () => goToStep(index + 1));
    });
    
    nextButtons.forEach(btn => {
        btn.addEventListener('click', () => nextStep());
    });
    
    prevButtons.forEach(btn => {
        btn.addEventListener('click', () => prevStep());
    });
}

let currentStep = 1;

function goToStep(step) {
    // Hide all steps
    document.querySelectorAll('.step-content').forEach(content => {
        content.classList.add('hidden');
    });
    
    // Show target step
    const targetStepContent = document.getElementById(`step-${step}`);
    if (targetStepContent) {
        targetStepContent.classList.remove('hidden');
        currentStep = step;
        updateStepIndicators();
    }
}

function nextStep() {
    if (validateCurrentStep()) {
        goToStep(currentStep + 1);
    }
}

function prevStep() {
    if (currentStep > 1) {
        goToStep(currentStep - 1);
    }
}

function validateCurrentStep() {
    const currentStepContent = document.getElementById(`step-${currentStep}`);
    const requiredFields = currentStepContent?.querySelectorAll('[required]');
    
    if (!requiredFields) return true;
    
    let isValid = true;
    requiredFields.forEach(field => {
        if (!field.value.trim()) {
            field.classList.add('border-red-500');
            isValid = false;
        } else {
            field.classList.remove('border-red-500');
        }
    });
    
    if (!isValid) {
        showNotification('请填写所有必填字段', 'error');
    }
    
    return isValid;
}

function updateStepIndicators() {
    document.querySelectorAll('.step-indicator').forEach((indicator, index) => {
        if (index + 1 === currentStep) {
            indicator.classList.add('active');
        } else {
            indicator.classList.remove('active');
        }
    });
}

// Instant Solutions functionality
function initializeInstantSolutions() {
    // Timer functionality for breathing exercises
    initializeBreathingTimer();
    
    // Heat therapy timer
    initializeHeatTimer();
    
    // Exercise video controls
    initializeExerciseVideos();
}

function initializeBreathingTimer() {
    const breathingTimer = document.getElementById('breathing-timer');
    if (!breathingTimer) return;
    
    const startBtn = breathingTimer.querySelector('.start-btn');
    const pauseBtn = breathingTimer.querySelector('.pause-btn');
    const resetBtn = breathingTimer.querySelector('.reset-btn');
    
    let breathingInterval;
    let isRunning = false;
    let currentCycle = 0;
    
    if (startBtn) {
        startBtn.addEventListener('click', startBreathingTimer);
    }
    
    if (pauseBtn) {
        pauseBtn.addEventListener('click', pauseBreathingTimer);
    }
    
    if (resetBtn) {
        resetBtn.addEventListener('click', resetBreathingTimer);
    }
}

function startBreathingTimer() {
    // Implementation for breathing timer
    console.log('Starting breathing timer...');
}

function pauseBreathingTimer() {
    console.log('Pausing breathing timer...');
}

function resetBreathingTimer() {
    console.log('Resetting breathing timer...');
}

function initializeHeatTimer() {
    const heatTimers = document.querySelectorAll('.heat-timer');
    heatTimers.forEach(timer => {
        const startBtn = timer.querySelector('.timer-start');
        const duration = timer.dataset.duration || 15;
        
        if (startBtn) {
            startBtn.addEventListener('click', () => startTimer(timer, duration));
        }
    });
}

function startTimer(timerElement, duration) {
    const display = timerElement.querySelector('.timer-display');
    const startBtn = timerElement.querySelector('.timer-start');
    let timeLeft = duration * 60; // Convert to seconds
    
    startBtn.textContent = '计时中...';
    startBtn.disabled = true;
    
    const interval = setInterval(() => {
        const minutes = Math.floor(timeLeft / 60);
        const seconds = timeLeft % 60;
        display.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
        
        timeLeft--;
        
        if (timeLeft < 0) {
            clearInterval(interval);
            display.textContent = '时间到！';
            startBtn.textContent = '重新开始';
            startBtn.disabled = false;
            
            // Show completion notification
            showNotification(`${duration}分钟热敷完成！记得休息一下。`, 'success');
        }
    }, 1000);
}

function initializeExerciseVideos() {
    const videos = document.querySelectorAll('.exercise-video');
    videos.forEach(video => {
        video.addEventListener('play', function() {
            // Pause other videos when one starts playing
            videos.forEach(otherVideo => {
                if (otherVideo !== video) {
                    otherVideo.pause();
                }
            });
        });
    });
}

// Regular Conditioning functionality  
function initializeRegularConditioning() {
    // Meal planner functionality
    initializeMealPlanner();
    
    // Exercise schedule
    initializeExerciseSchedule();
    
    // Progress tracking
    initializeProgressTracking();
}

function initializeMealPlanner() {
    const mealPlanners = document.querySelectorAll('.meal-planner');
    mealPlanners.forEach(planner => {
        const checkboxes = planner.querySelectorAll('input[type="checkbox"]');
        checkboxes.forEach(checkbox => {
            checkbox.addEventListener('change', function() {
                if (this.checked) {
                    this.parentElement.classList.add('completed');
                } else {
                    this.parentElement.classList.remove('completed');
                }
                updateMealProgress(planner);
            });
        });
    });
}

function updateMealProgress(planner) {
    const checkboxes = planner.querySelectorAll('input[type="checkbox"]');
    const checked = planner.querySelectorAll('input[type="checkbox"]:checked');
    const progressBar = planner.querySelector('.progress-bar');
    
    if (progressBar) {
        const progress = (checked.length / checkboxes.length) * 100;
        progressBar.style.width = `${progress}%`;
    }
}

function initializeExerciseSchedule() {
    const exerciseCards = document.querySelectorAll('.exercise-card');
    exerciseCards.forEach(card => {
        const completeBtn = card.querySelector('.mark-complete');
        if (completeBtn) {
            completeBtn.addEventListener('click', function() {
                card.classList.toggle('completed');
                this.textContent = card.classList.contains('completed') ? '已完成' : '标记完成';
            });
        }
    });
}

function initializeProgressTracking() {
    // Load progress from localStorage
    loadProgress();
    
    // Save progress when values change
    const progressInputs = document.querySelectorAll('.progress-input');
    progressInputs.forEach(input => {
        input.addEventListener('change', saveProgress);
    });
}

function loadProgress() {
    const savedProgress = localStorage.getItem('period-health-progress');
    if (savedProgress) {
        const progress = JSON.parse(savedProgress);
        Object.keys(progress).forEach(key => {
            const input = document.getElementById(key);
            if (input) {
                input.value = progress[key];
            }
        });
    }
}

function saveProgress() {
    const progressInputs = document.querySelectorAll('.progress-input');
    const progress = {};
    
    progressInputs.forEach(input => {
        progress[input.id] = input.value;
    });
    
    localStorage.setItem('period-health-progress', JSON.stringify(progress));
    showNotification('进度已保存', 'success');
}

// FAQ functionality
function initializeFAQ() {
    const faqItems = document.querySelectorAll('.faq-item');
    
    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');
        const answer = item.querySelector('.faq-answer');
        const icon = item.querySelector('.faq-icon');
        
        question.addEventListener('click', () => {
            const isOpen = !answer.classList.contains('hidden');
            
            // Close all FAQ items
            faqItems.forEach(otherItem => {
                otherItem.querySelector('.faq-answer').classList.add('hidden');
                otherItem.querySelector('.faq-icon').style.transform = 'rotate(0deg)';
            });
            
            // Open clicked item if it was closed
            if (!isOpen) {
                answer.classList.remove('hidden');
                icon.style.transform = 'rotate(180deg)';
            }
        });
    });
}

// General features for all pages
function initializeGeneralFeatures() {
    // Tab functionality
    initializeTabs();
    
    // Accordion functionality  
    initializeAccordions();
    
    // Modal functionality
    initializeModals();
    
    // Copy to clipboard functionality
    initializeCopyFunctionality();
}

function initializeTabs() {
    const tabContainers = document.querySelectorAll('.tab-container');
    
    tabContainers.forEach(container => {
        const tabButtons = container.querySelectorAll('.tab-button');
        const tabContents = container.querySelectorAll('.tab-content');
        
        tabButtons.forEach((button, index) => {
            button.addEventListener('click', () => {
                // Remove active class from all tabs and contents
                tabButtons.forEach(btn => btn.classList.remove('active'));
                tabContents.forEach(content => content.classList.add('hidden'));
                
                // Add active class to clicked tab and show corresponding content
                button.classList.add('active');
                if (tabContents[index]) {
                    tabContents[index].classList.remove('hidden');
                }
            });
        });
    });
}

function initializeAccordions() {
    const accordionItems = document.querySelectorAll('.accordion-item');
    
    accordionItems.forEach(item => {
        const header = item.querySelector('.accordion-header');
        const content = item.querySelector('.accordion-content');
        
        header.addEventListener('click', () => {
            const isOpen = content.style.maxHeight;
            
            if (isOpen) {
                content.style.maxHeight = null;
                item.classList.remove('active');
            } else {
                content.style.maxHeight = content.scrollHeight + 'px';
                item.classList.add('active');
            }
        });
    });
}

function initializeModals() {
    const modalTriggers = document.querySelectorAll('[data-modal-target]');
    const modalCloses = document.querySelectorAll('[data-modal-close]');
    
    modalTriggers.forEach(trigger => {
        trigger.addEventListener('click', (e) => {
            e.preventDefault();
            const targetId = trigger.dataset.modalTarget;
            const modal = document.getElementById(targetId);
            if (modal) {
                modal.classList.remove('hidden');
                modal.classList.add('flex');
                document.body.style.overflow = 'hidden';
            }
        });
    });
    
    modalCloses.forEach(closeBtn => {
        closeBtn.addEventListener('click', () => {
            closeBtn.closest('.modal').classList.add('hidden');
            closeBtn.closest('.modal').classList.remove('flex');
            document.body.style.overflow = 'auto';
        });
    });
    
    // Close modal when clicking outside
    window.addEventListener('click', (e) => {
        if (e.target.classList.contains('modal')) {
            e.target.classList.add('hidden');
            e.target.classList.remove('flex');
            document.body.style.overflow = 'auto';
        }
    });
}

function initializeCopyFunctionality() {
    const copyButtons = document.querySelectorAll('.copy-btn');
    
    copyButtons.forEach(button => {
        button.addEventListener('click', async () => {
            const targetId = button.dataset.copyTarget;
            const targetElement = document.getElementById(targetId);
            
            if (targetElement) {
                try {
                    await navigator.clipboard.writeText(targetElement.textContent);
                    showNotification('已复制到剪贴板', 'success');
                } catch (err) {
                    console.error('Failed to copy text: ', err);
                    showNotification('复制失败', 'error');
                }
            }
        });
    });
}

// Utility functions
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

// Export functions for testing or external use
if (typeof window !== 'undefined') {
    window.periodHealth = {
        showNotification,
        initializeNavigation,
        initializeScrollAnimations,
        initializeMultiStepForm,
        goToStep,
        nextStep,
        prevStep
    };
}

// Error handling
window.addEventListener('error', function(e) {
    console.error('JavaScript error:', e.error);
    // Could send error reports to a logging service
});

// Service Worker registration (if available)
if ('serviceWorker' in navigator) {
    window.addEventListener('load', function() {
        navigator.serviceWorker.register('/sw.js')
            .then(function(registration) {
                console.log('ServiceWorker registration successful');
            })
            .catch(function(err) {
                console.log('ServiceWorker registration failed: ', err);
            });
    });
}
