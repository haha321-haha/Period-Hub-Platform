document.addEventListener('DOMContentLoaded', () => {
    const loadMarkdownContent = async () => {
        const contentContainer = document.getElementById('content-container');
        if (!contentContainer) {
            console.error('Content container not found!');
            return;
        }

        try {
            const response = await fetch('iud_guide.md');
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const markdownText = await response.text();
            

            if (window.marked) {
                contentContainer.innerHTML = window.marked.parse(markdownText);
            } else {
                 throw new Error('Marked.js library not loaded.');
            }

        } catch (error) {
            console.error('Error loading or parsing markdown file:', error);
            contentContainer.innerHTML = `
                <div class="text-center text-red-600 bg-red-100 p-4 rounded-lg">
                    <p class="font-bold">内容加载失败</p>
                    <p class="text-sm">很抱歉，我们无法加载文章内容。请刷新页面重试。</p>
                </div>
            `;
        }
    };

    loadMarkdownContent().then(() => {

        if (window.lucide) {
            lucide.createIcons();
        }
    });
});
