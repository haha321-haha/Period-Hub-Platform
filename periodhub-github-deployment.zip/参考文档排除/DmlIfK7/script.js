document.addEventListener('DOMContentLoaded', () => {
    lucide.createIcons();


    const mobileMenuButton = document.getElementById('mobile-menu-button');
    const mobileMenu = document.getElementById('mobile-menu');
    if (mobileMenuButton && mobileMenu) {
        mobileMenuButton.addEventListener('click', () => {
            mobileMenu.classList.toggle('hidden');
        });

        mobileMenu.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                mobileMenu.classList.add('hidden');
            });
        });
    }
    


    const drugSelect = document.getElementById('drug-select');
    const weightInput = document.getElementById('weight-input');
    const calculateButton = document.getElementById('calculate-dose-button');
    const doseResultDiv = document.getElementById('dose-result');
    const resultDrugName = document.getElementById('result-drug-name');
    const resultSingleDose = document.getElementById('result-single-dose');
    const resultMaxDailyDose = document.getElementById('result-max-daily-dose');
    const resultNotes = document.getElementById('result-notes');

    if (calculateButton) {
        calculateButton.addEventListener('click', () => {
            const selectedDrug = drugSelect.value;
            const weight = parseFloat(weightInput.value);

            if (isNaN(weight) || weight <= 0) {

                doseResultDiv.classList.add('hidden');
                resultDrugName.textContent = '';
                resultSingleDose.textContent = '';
                resultMaxDailyDose.textContent = '';
                resultNotes.textContent = '';


                alert('请输入有效的体重。');
                return;
            }


            let drugNameDisplay = '';
            let singleDose = '';
            let maxDailyDose = '';
            let notes = '';

            if (selectedDrug === 'ibuprofen') {
                drugNameDisplay = '布洛芬 (Ibuprofen)';
                singleDose = '200 - 400 mg';
                maxDailyDose = '1200 mg (若需更高剂量或长期使用，请咨询医生。部分处方情况下可达2400mg)';
                notes = '成人常用剂量，通常每4-6小时一次。请勿超过每日最大剂量。';
            } else if (selectedDrug === 'naproxen') {
                drugNameDisplay = '萘普生 (Naproxen)';
                singleDose = '首次剂量500 mg，之后根据需要可服用250 - 500 mg';
                maxDailyDose = '1250 mg';
                notes = '通常每6-12小时一次。请勿超过每日最大剂量。';
            }

            resultDrugName.textContent = drugNameDisplay;
            resultSingleDose.textContent = singleDose;
            resultMaxDailyDose.textContent = maxDailyDose;
            resultNotes.textContent = notes;
            
            doseResultDiv.classList.remove('hidden');
        });
    }
});
