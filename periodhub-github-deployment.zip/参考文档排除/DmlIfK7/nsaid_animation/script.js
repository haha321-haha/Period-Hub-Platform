import { scenes } from './data.js';

document.addEventListener('DOMContentLoaded', () => {
    lucide.createIcons();

    const videoPlayer = document.getElementById('animationPlayer');
    const sceneTitleElement = document.getElementById('sceneTitle');
    const narrationTextElement = document.getElementById('narrationText');
    const prevButton = document.getElementById('prevButton');
    const nextButton = document.getElementById('nextButton');
    const sceneIndicatorElement = document.getElementById('sceneIndicator');

    let currentSceneIndex = 0;

    function loadScene(index) {
        if (index < 0 || index >= scenes.length) {
            console.error('Scene index out of bounds:', index);
            return;
        }

        currentSceneIndex = index;
        const scene = scenes[currentSceneIndex];

        videoPlayer.src = scene.videoUrl;
        videoPlayer.poster = ''; // Clear poster if any
        sceneTitleElement.textContent = scene.title;
        narrationTextElement.textContent = scene.narration;
        sceneIndicatorElement.textContent = `场景 ${scene.id} / ${scenes.length}`;
        


        videoPlayer.load(); // Ensure the new source is loaded
        const playPromise = videoPlayer.play();
        if (playPromise !== undefined) {
            playPromise.catch(error => {
                console.warn("Autoplay prevented for scene:", scene.id, error);

            });
        }
        updateNavigationButtons();
    }

    function updateNavigationButtons() {
        prevButton.disabled = currentSceneIndex === 0;
        nextButton.disabled = currentSceneIndex === scenes.length - 1;
    }

    function playNextScene() {
        if (currentSceneIndex < scenes.length - 1) {
            currentSceneIndex++;
            loadScene(currentSceneIndex);
        } else {

             currentSceneIndex = 0;
             loadScene(currentSceneIndex);
        }
    }

    function playPrevScene() {
        if (currentSceneIndex > 0) {
            currentSceneIndex--;
            loadScene(currentSceneIndex);
        }
    }

    videoPlayer.addEventListener('ended', () => {



    });

    videoPlayer.addEventListener('error', (e) => {
        console.error('Video error:', e);
        narrationTextElement.textContent = '抱歉，视频加载失败。请检查您的网络连接或稍后再试。';
        sceneTitleElement.textContent = '视频加载错误';
    });
    
    prevButton.addEventListener('click', () => {
        playPrevScene();
    });

    nextButton.addEventListener('click', () => {
        playNextScene();
    });


    if (scenes && scenes.length > 0) {
        loadScene(0);
    } else {
        sceneTitleElement.textContent = "没有可播放的场景";
        narrationTextElement.textContent = "请检查数据配置。";
        prevButton.disabled = true;
        nextButton.disabled = true;
        sceneIndicatorElement.textContent = "场景 0 / 0";
    }
});

