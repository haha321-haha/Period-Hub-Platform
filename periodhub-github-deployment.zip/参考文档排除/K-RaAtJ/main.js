// Main JavaScript functionality for period.health
document.addEventListener('DOMContentLoaded', function() {
    console.log('period.health website loaded');
    
    // Initialize mobile menu
    initializeMobileMenu();
    
    // Initialize interactive features
    initializeInteractiveFeatures();
    
    // Initialize form handlers
    initializeFormHandlers();
    
    // Initialize scroll animations
    initializeScrollAnimations();
});

// Mobile Menu functionality
function initializeMobileMenu() {
    const mobileMenuBtn = document.getElementById('mobile-menu-btn');
    const mobileMenu = document.getElementById('mobile-menu');
    
    if (mobileMenuBtn && mobileMenu) {
        mobileMenuBtn.addEventListener('click', function() {
            mobileMenu.classList.toggle('hidden');
        });
        
        // Close menu when clicking outside
        document.addEventListener('click', function(event) {
            if (!mobileMenuBtn.contains(event.target) && !mobileMenu.contains(event.target)) {
                mobileMenu.classList.add('hidden');
            }
        });
    }
}

// Interactive Features for Assessment and Tools
function initializeInteractiveFeatures() {
    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

// Assessment Tool Functions
function startAssessment() {
    console.log('Starting symptom assessment...');
    
    // Hide other sections
    hideAllSections();
    
    // Show assessment section
    const assessmentSection = document.getElementById('assessment-section');
    if (assessmentSection) {
        assessmentSection.style.display = 'block';
        assessmentSection.scrollIntoView({ behavior: 'smooth' });
    }
    
    // Initialize assessment form
    initializeAssessmentForm();
}

function hideAllSections() {
    const sections = ['assessment-section', 'recommendations-section', 'tracker-section'];
    sections.forEach(sectionId => {
        const section = document.getElementById(sectionId);
        if (section) {
            section.style.display = 'none';
        }
    });
}

function initializeAssessmentForm() {
    console.log('Assessment form initialized');
    // Add any specific form initialization logic here
}

function submitAssessment() {
    console.log('Submitting assessment...');
    
    // Collect form data
    const formData = collectAssessmentData();
    
    // Validate form data
    if (!validateAssessmentData(formData)) {
        alert('请完成所有必填项目');
        return;
    }
    
    // Process assessment data
    const recommendations = processAssessmentData(formData);
    
    // Show recommendations
    showRecommendations(recommendations);
}

function collectAssessmentData() {
    const data = {};
    
    // Pain level
    const painLevel = document.querySelector('input[name="pain-level"]:checked');
    data.painLevel = painLevel ? painLevel.value : null;
    
    // Symptoms
    const symptoms = [];
    document.querySelectorAll('input[type="checkbox"]:checked').forEach(checkbox => {
        symptoms.push(checkbox.parentElement.textContent.trim());
    });
    data.symptoms = symptoms;
    
    // Duration
    const duration = document.querySelector('select').value;
    data.duration = duration;
    
    // Impact
    const impact = document.querySelector('input[name="impact"]:checked');
    data.impact = impact ? impact.value : null;
    
    return data;
}

function validateAssessmentData(data) {
    return data.painLevel && data.impact && data.duration;
}

function processAssessmentData(data) {
    // Simple recommendation engine
    const recommendations = {
        immediate: [],
        longTerm: [],
        severity: 'mild'
    };
    
    // Determine severity based on pain level and impact
    if (data.painLevel === '7-10' || data.impact === 'severe') {
        recommendations.severity = 'severe';
        recommendations.immediate = [
            '使用热敷袋进行腹部热敷',
            '服用非处方止痛药（如布洛芬）',
            '尝试深呼吸练习',
            '考虑就医咨询'
        ];
        recommendations.longTerm = [
            '建立规律的运动习惯',
            '调整饮食结构',
            '学习压力管理技巧',
            '定期医学检查'
        ];
    } else if (data.painLevel === '4-6' || data.impact === 'moderate') {
        recommendations.severity = 'moderate';
        recommendations.immediate = [
            '热敷腹部15-20分钟',
            '进行轻度瑜伽伸展',
            '喝温热的草药茶',
            '保持充足休息'
        ];
        recommendations.longTerm = [
            '增加有氧运动',
            '补充镁元素',
            '改善睡眠质量',
            '减少咖啡因摄入'
        ];
    } else {
        recommendations.severity = 'mild';
        recommendations.immediate = [
            '轻度腹部按摩',
            '温水浸泡',
            '适度散步',
            '放松心情'
        ];
        recommendations.longTerm = [
            '保持规律作息',
            '均衡营养摄入',
            '适度运动',
            '记录月经周期'
        ];
    }
    
    return recommendations;
}

function showRecommendations(recommendations) {
    hideAllSections();
    
    const recommendationsSection = document.getElementById('recommendations-section');
    if (recommendationsSection) {
        // Update recommendations content
        const resultsDiv = document.getElementById('recommendation-results');
        if (resultsDiv) {
            resultsDiv.innerHTML = `
                <div class="bg-purple-50 p-6 rounded-lg mb-6">
                    <h3 class="text-lg font-semibold mb-3">基于您的评估结果：</h3>
                    <div class="grid md:grid-cols-2 gap-4">
                        <div class="bg-white p-4 rounded-lg">
                            <h4 class="font-semibold text-purple-600 mb-2">即时缓解建议</h4>
                            <ul class="text-sm space-y-1">
                                ${recommendations.immediate.map(item => `<li>• ${item}</li>`).join('')}
                            </ul>
                        </div>
                        <div class="bg-white p-4 rounded-lg">
                            <h4 class="font-semibold text-purple-600 mb-2">长期调理建议</h4>
                            <ul class="text-sm space-y-1">
                                ${recommendations.longTerm.map(item => `<li>• ${item}</li>`).join('')}
                            </ul>
                        </div>
                    </div>
                </div>
                
                <div class="text-center">
                    <a href="instant-solutions.html" class="bg-purple-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-purple-700 transition-colors mr-4">查看详细方法</a>
                    <button onclick="savePlan()" class="border border-purple-600 text-purple-600 px-6 py-3 rounded-lg font-semibold hover:bg-purple-50 transition-colors">保存方案</button>
                </div>
            `;
        }
        
        recommendationsSection.style.display = 'block';
        recommendationsSection.scrollIntoView({ behavior: 'smooth' });
    }
}

function showPersonalizedPlan() {
    console.log('Showing personalized plan...');
    // This would typically require user data or assessment results
    alert('请先完成症状评估以获取个性化方案');
    startAssessment();
}

function savePlan() {
    console.log('Saving personalized plan...');
    
    // Save to localStorage for demo purposes
    const planData = {
        timestamp: new Date().toISOString(),
        recommendations: 'User personalized plan'
    };
    
    localStorage.setItem('period-health-plan', JSON.stringify(planData));
    
    alert('方案已保存！您可以在任何时候回来查看您的个性化建议。');
}

// Pain Tracker Functions
function openPainTracker() {
    console.log('Opening pain tracker...');
    
    hideAllSections();
    
    const trackerSection = document.getElementById('tracker-section');
    if (trackerSection) {
        // Set today's date
        const dateInput = document.getElementById('pain-date');
        if (dateInput) {
            dateInput.value = new Date().toISOString().split('T')[0];
        }
        
        trackerSection.style.display = 'block';
        trackerSection.scrollIntoView({ behavior: 'smooth' });
    }
}

function updatePainValue(value) {
    const painValueSpan = document.getElementById('pain-value');
    if (painValueSpan) {
        painValueSpan.textContent = value;
    }
}

function savePainRecord() {
    console.log('Saving pain record...');
    
    // Collect pain tracker data
    const date = document.getElementById('pain-date').value;
    const painLevel = document.getElementById('pain-scale').value;
    const symptoms = document.querySelector('textarea').value;
    const methods = document.querySelector('input[type="text"]').value;
    
    if (!date || !painLevel) {
        alert('请填写日期和疼痛等级');
        return;
    }
    
    // Save to localStorage (in real app, would save to database)
    const record = {
        date,
        painLevel,
        symptoms,
        methods,
        timestamp: new Date().toISOString()
    };
    
    // Get existing records
    const existingRecords = JSON.parse(localStorage.getItem('pain-records') || '[]');
    existingRecords.push(record);
    localStorage.setItem('pain-records', JSON.stringify(existingRecords));
    
    alert('疼痛记录已保存！');
    
    // Clear form
    document.querySelector('textarea').value = '';
    document.querySelector('input[type="text"]').value = '';
    document.getElementById('pain-scale').value = 5;
    updatePainValue(5);
}

// Breathing Exercise Functions
function startBreathingExercise() {
    console.log('Starting breathing exercise...');
    
    const button = document.getElementById('breathing-timer');
    if (!button) return;
    
    button.textContent = '准备开始...';
    button.disabled = true;
    
    let currentPhase = 0;
    const phases = [
        { name: '吸气', duration: 4, color: 'bg-blue-600' },
        { name: '屏息', duration: 7, color: 'bg-purple-600' },
        { name: '呼气', duration: 8, color: 'bg-pink-600' }
    ];
    
    function runPhase() {
        if (currentPhase >= phases.length) {
            // Reset after one complete cycle
            currentPhase = 0;
            button.textContent = '再次练习';
            button.disabled = false;
            button.className = 'bg-purple-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-purple-700 transition-colors';
            return;
        }
        
        const phase = phases[currentPhase];
        let timeLeft = phase.duration;
        
        button.className = `${phase.color} text-white px-8 py-3 rounded-lg font-semibold transition-colors`;
        
        const interval = setInterval(() => {
            button.textContent = `${phase.name} ${timeLeft}秒`;
            timeLeft--;
            
            if (timeLeft < 0) {
                clearInterval(interval);
                currentPhase++;
                setTimeout(runPhase, 500);
            }
        }, 1000);
    }
    
    // Start after 2 seconds
    setTimeout(runPhase, 2000);
}

// Form Handlers
function initializeFormHandlers() {
    // Newsletter subscription
    const newsletterForm = document.querySelector('form');
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const email = this.querySelector('input[type="email"]').value;
            if (email) {
                alert('感谢订阅！我们将定期为您发送健康资讯。');
                this.reset();
            }
        });
    }
    
    // Search functionality
    const searchInput = document.querySelector('input[type="search"]');
    if (searchInput) {
        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                const searchTerm = this.value;
                if (searchTerm) {
                    console.log('Searching for:', searchTerm);
                    // Implement search functionality
                    alert(`搜索功能开发中。搜索词: ${searchTerm}`);
                }
            }
        });
    }
}

// Scroll to section function
function scrollToSection(sectionId) {
    const element = document.getElementById(sectionId);
    if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
    }
}

// Scroll animations
function initializeScrollAnimations() {
    // Add intersection observer for fade-in animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-fade-in');
            }
        });
    }, observerOptions);
    
    // Observe sections for animation
    document.querySelectorAll('section').forEach(section => {
        observer.observe(section);
    });
}

// Utility functions
function showLoading() {
    console.log('Loading...');
}

function hideLoading() {
    console.log('Loading complete');
}

// Error handling
window.addEventListener('error', function(e) {
    console.error('JavaScript error:', e.error);
});

// Export functions for global access
window.startAssessment = startAssessment;
window.submitAssessment = submitAssessment;
window.showPersonalizedPlan = showPersonalizedPlan;
window.savePlan = savePlan;
window.openPainTracker = openPainTracker;
window.updatePainValue = updatePainValue;
window.savePainRecord = savePainRecord;
window.startBreathingExercise = startBreathingExercise;
window.scrollToSection = scrollToSection;

