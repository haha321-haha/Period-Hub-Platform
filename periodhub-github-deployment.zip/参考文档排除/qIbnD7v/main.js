document.addEventListener('DOMContentLoaded', function() {
    // Pain level evaluation
    const evaluateButton = document.getElementById('evaluate-button');
    const evaluationResult = document.getElementById('evaluation-result');
    const painLevel = document.getElementById('pain-level');
    const dailyImpact = document.getElementById('daily-impact');
    const painDuration = document.getElementById('pain-duration');

    evaluateButton.addEventListener('click', function() {
        const painScore = parseInt(painLevel.value);
        const impact = dailyImpact.value;
        const duration = painDuration.value;
        
        let severityLevel = '';
        let recommendations = [];
        
        // Determine severity level
        if (painScore <= 3 && impact === 'low' && duration === 'short') {
            severityLevel = '轻度痛经';
            recommendations = [
                '热敷：每天2-3次，每次15-20分钟',
                '生姜茶：每天1-2杯',
                '轻柔瑜伽：侧卧婴儿式、膝盖对胸式等舒缓体式',
                '三阴交穴位按摩：每天2-3次，每次5分钟'
            ];
        } else if (painScore <= 7 && (impact === 'medium' || duration === 'medium')) {
            severityLevel = '中度痛经';
            recommendations = [
                '热敷：每2-3小时一次，每次20分钟',
                '姜黄素补充剂（遵医嘱）：每天500-1000mg',
                '镁补充（遵医嘱）：每天300-400mg',
                '艾灸关元穴：每天1次，每次15-20分钟',
                '5分钟经期舒缓瑜伽序列：每天1-2次',
                '马郁兰+薰衣草精油按摩：腹部轻柔按摩，每天1-2次'
            ];
        } else {
            severityLevel = '重度痛经';
            recommendations = [
                '建议咨询医疗专业人员，排除子宫内膜异位症等器质性疾病',
                '综合疗法：热敷+TENS+穴位按压+腹式呼吸',
                '艾灸关元穴和命门穴：每天1-2次',
                '强化营养补充（遵医嘱）：镁、维生素B6、Omega-3、姜黄素',
                '考虑专业针灸治疗',
                '结合本指南的"重度痛经综合方案"，在医疗监督下使用'
            ];
        }
        
        // Display results
        evaluationResult.innerHTML = `
            <h4 class="font-semibold text-lg mb-2">评估结果</h4>
            <p class="mb-2">根据您的输入，您可能正在经历<span class="font-bold text-rose-600">${severityLevel}</span>。</p>
            <p class="mb-2">推荐的自然疗法组合：</p>
            <ul class="list-disc pl-6 space-y-1">
                ${recommendations.map(rec => `<li>${rec}</li>`).join('')}
            </ul>
            <p class="mt-2 text-sm text-gray-600">注意：此评估仅供参考，不构成医疗建议。如有严重症状，请咨询医疗专业人士。</p>
        `;
        
        evaluationResult.classList.remove('hidden');
    });

    // Mobile menu toggle
    const mobileMenuButton = document.getElementById('mobile-menu-button');
    if (mobileMenuButton) {
        let mobileMenuOpen = false;
        const mobileMenuContent = document.createElement('div');
        mobileMenuContent.className = 'sm:hidden bg-white pb-3 pt-2 px-4 hidden';
        mobileMenuContent.innerHTML = `
            <div class="space-y-1">
                <a href="#" class="block px-3 py-2 rounded-md text-base font-medium text-gray-900 bg-gray-50">首页</a>
                <a href="#" class="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-gray-900 hover:bg-gray-50">自然疗法</a>
                <a href="#" class="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-gray-900 hover:bg-gray-50">互动解决方案</a>
                <a href="#" class="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-gray-900 hover:bg-gray-50">痛经原因</a>
            </div>
        `;
        
        document.querySelector('nav').appendChild(mobileMenuContent);
        
        mobileMenuButton.addEventListener('click', function() {
            mobileMenuOpen = !mobileMenuOpen;
            if (mobileMenuOpen) {
                mobileMenuContent.classList.remove('hidden');
            } else {
                mobileMenuContent.classList.add('hidden');
            }
        });
    }

    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 80, // Offset for fixed header
                    behavior: 'smooth'
                });
            }
        });
    });

    // Highlight current section in navigation based on scroll position
    const sections = document.querySelectorAll('section[id]');
    
    function highlightCurrentSection() {
        const scrollPosition = window.scrollY + 100; // Offset for header
        
        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.offsetHeight;
            
            if (scrollPosition >= sectionTop && scrollPosition < sectionTop + sectionHeight) {
                const correspondingNavLink = document.querySelector(`a[href="#${section.id}"]`);
                if (correspondingNavLink) {
                    document.querySelectorAll('a[href^="#"]').forEach(link => {
                        link.classList.remove('text-rose-600');
                    });
                    correspondingNavLink.classList.add('text-rose-600');
                }
            }
        });
    }
    
    window.addEventListener('scroll', highlightCurrentSection);
    
    // Initialize section highlighting
    highlightCurrentSection();
    
    // Track interactions for popular sections
    const sectionInteractions = {};
    
    sections.forEach(section => {
        sectionInteractions[section.id] = 0;
        
        // Track clicks on section links
        const sectionLinks = document.querySelectorAll(`a[href="#${section.id}"]`);
        sectionLinks.forEach(link => {
            link.addEventListener('click', () => {
                sectionInteractions[section.id]++;
                console.log(`Section ${section.id} interactions: ${sectionInteractions[section.id]}`);
            });
        });
    });
    
    // Simple visibility tracking
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const sectionId = entry.target.id;
                if (sectionId && sectionInteractions[sectionId] !== undefined) {
                    sectionInteractions[sectionId]++;
                    console.log(`Section ${sectionId} viewed: ${sectionInteractions[sectionId]}`);
                }
            }
        });
    }, { threshold: 0.5 });
    
    sections.forEach(section => {
        observer.observe(section);
    });
});
