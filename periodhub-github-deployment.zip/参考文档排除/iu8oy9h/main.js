document.addEventListener('DOMContentLoaded', function() {
    // 移动端菜单切换
    const menuButton = document.querySelector('button.md\\:hidden');
    const mobileMenu = document.getElementById('mobile-menu');
    
    if (menuButton && mobileMenu) {
        menuButton.addEventListener('click', function() {
            if (mobileMenu.classList.contains('hidden')) {
                mobileMenu.classList.remove('hidden');
            } else {
                mobileMenu.classList.add('hidden');
            }
        });
    }
    
    // 平滑滚动到锚点
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                targetElement.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
                
                // 如果是在移动端菜单点击的，关闭菜单
                if (mobileMenu && !mobileMenu.classList.contains('hidden')) {
                    mobileMenu.classList.add('hidden');
                }
            }
        });
    });

    // 目录激活状态追踪
    const observeHeadings = () => {
        const headings = document.querySelectorAll('article[id]');
        const tocLinks = document.querySelectorAll('#table-of-contents a');
        
        if (headings.length === 0 || tocLinks.length === 0) return;
        
        const observerOptions = {
            rootMargin: '-100px 0px -80% 0px',
            threshold: 0
        };
        
        const headingObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    // 移除所有链接的激活状态
                    tocLinks.forEach(link => {
                        link.classList.remove('text-primary', 'font-semibold');
                    });
                    
                    // 添加当前链接的激活状态
                    const activeLink = document.querySelector(`#table-of-contents a[href="#${entry.target.id}"]`);
                    if (activeLink) {
                        activeLink.classList.add('text-primary', 'font-semibold');
                    }
                }
            });
        }, observerOptions);
        
        headings.forEach(heading => {
            headingObserver.observe(heading);
        });
    };
    
    observeHeadings();

    // 痛经快速自测功能
    const setupPainTest = () => {
        const submitButton = document.getElementById('test-submit');
        const resultDiv = document.getElementById('test-result');
        const resultText = document.getElementById('result-text');
        
        if (!submitButton || !resultDiv || !resultText) return;
        
        submitButton.addEventListener('click', () => {
            // 获取用户选择
            const q1 = document.querySelector('input[name="q1"]:checked');
            const q2 = document.querySelector('input[name="q2"]:checked');
            const q3a = document.getElementById('q3a').checked;
            const q3b = document.getElementById('q3b').checked;
            const q3c = document.getElementById('q3c').checked;
            const q3d = document.getElementById('q3d').checked;
            
            if (!q1 || !q2) {
                alert('请回答所有问题');
                return;
            }
            
            // 分析结果
            let result = '';
            let type = '';
            
            // 基于选择确定可能的痛经类型
            if (q1.id === 'q1a' && q2.id === 'q2a' && !(q3b || q3c || q3d)) {
                type = 'original';
                result = '您的痛经特征与原发性痛经相符。原发性痛经通常在初潮后1-2年开始，疼痛集中在月经开始前后，无其他器质性疾病症状。';
            } else if ((q1.id === 'q1b' || q1.id === 'q1c') || q2.id === 'q2b' || q3b || q3c || q3d) {
                type = 'secondary';
                result = '您的痛经特征提示可能存在继发性痛经。继发性痛经通常在25岁后或生育后出现，疼痛可能持续整个月经期，并伴有性交痛、月经量异常等症状。建议咨询医生进行评估。';
            } else {
                type = 'mixed';
                result = '您的痛经表现特征不典型，可能需要进一步评估以确定类型。建议记录详细症状并咨询医生。';
            }
            
            // 显示结果
            resultText.textContent = result;
            resultDiv.classList.remove('hidden');
            
            // 添加建议
            if (type === 'original') {
                resultText.innerHTML += '<br><br>建议：尝试非甾体抗炎药(如布洛芬)、热敷、轻度运动等缓解方法。若疼痛严重影响生活，可考虑口服避孕药等激素治疗。';
            } else if (type === 'secondary') {
                resultText.innerHTML += '<br><br>建议：建议咨询妇科医生，进行盆腔检查和必要的影像学检查，排除子宫内膜异位症等器质性疾病。';
            } else {
                resultText.innerHTML += '<br><br>建议：建议使用月经记录APP记录痛经模式，并在疼痛严重时及时就医。';
            }
        });
    };
    
    setupPainTest();

    // 处理紧急求助按钮
    const setupEmergencyHelp = () => {
        const emergencyButtons = document.querySelectorAll('.emergency-help-btn');
        
        emergencyButtons.forEach(button => {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                
                // 创建模态框
                const modal = document.createElement('div');
                modal.className = 'fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center';
                
                modal.innerHTML = `
                    <div class="bg-white rounded-lg p-6 max-w-md w-full mx-4">
                        <h3 class="text-xl font-bold text-primary mb-4">紧急痛经求助</h3>
                        <div class="mb-4">
                            <p class="mb-2 font-medium">请选择您的紧急情况:</p>
                            <div class="space-y-2">
                                <div class="flex items-center">
                                    <input type="radio" id="severe-pain" name="emergency" class="mr-2">
                                    <label for="severe-pain">痛经非常严重，无法忍受</label>
                                </div>
                                <div class="flex items-center">
                                    <input type="radio" id="fever" name="emergency" class="mr-2">
                                    <label for="fever">痛经伴有发热</label>
                                </div>
                                <div class="flex items-center">
                                    <input type="radio" id="vomiting" name="emergency" class="mr-2">
                                    <label for="vomiting">痛经伴有剧烈呕吐</label>
                                </div>
                                <div class="flex items-center">
                                    <input type="radio" id="fainting" name="emergency" class="mr-2">
                                    <label for="fainting">痛经导致昏厥或将要昏厥</label>
                                </div>
                                <div class="flex items-center">
                                    <input type="radio" id="other" name="emergency" class="mr-2">
                                    <label for="other">其他严重情况</label>
                                </div>
                            </div>
                        </div>
                        <div class="flex justify-end space-x-3">
                            <button id="close-modal" class="px-4 py-2 border border-gray-300 rounded-lg">关闭</button>
                            <button id="get-help" class="px-4 py-2 bg-primary text-white rounded-lg">获取帮助</button>
                        </div>
                    </div>
                `;
                
                document.body.appendChild(modal);
                
                // 关闭模态框
                document.getElementById('close-modal').addEventListener('click', function() {
                    document.body.removeChild(modal);
                });
                
                // 获取帮助按钮
                document.getElementById('get-help').addEventListener('click', function() {
                    const selectedOption = document.querySelector('input[name="emergency"]:checked');
                    
                    if (!selectedOption) {
                        alert('请选择一个选项');
                        return;
                    }
                    
                    // 根据选择生成不同的建议
                    let advice = '';
                    let needEmergency = false;
                    
                    switch(selectedOption.id) {
                        case 'severe-pain':
                            advice = '请尝试热敷下腹部、使用非处方止痛药（如布洛芬），并保持休息。若2小时后疼痛无缓解，建议就医。';
                            break;
                        case 'fever':
                            advice = '痛经伴发热可能提示感染，建议尽快就医。';
                            needEmergency = true;
                            break;
                        case 'vomiting':
                            advice = '剧烈呕吐可能导致脱水，请补充液体，并尽快就医。';
                            needEmergency = true;
                            break;
                        case 'fainting':
                            advice = '昏厥是严重症状，需立即就医。请立即呼叫急救或前往最近的急诊室。';
                            needEmergency = true;
                            break;
                        case 'other':
                            advice = '严重不适需要专业评估，建议尽快就医。';
                            needEmergency = true;
                            break;
                    }
                    
                    // 更新模态框内容显示建议
                    modal.innerHTML = `
                        <div class="bg-white rounded-lg p-6 max-w-md w-full mx-4">
                            <h3 class="text-xl font-bold ${needEmergency ? 'text-red-600' : 'text-primary'} mb-4">
                                ${needEmergency ? '紧急情况建议' : '缓解建议'}
                            </h3>
                            <p class="mb-6">${advice}</p>
                            ${needEmergency ? 
                                `<div class="bg-red-50 p-4 rounded-lg mb-4">
                                    <p class="text-red-600 font-medium">您的症状需要医疗评估，请尽快就医。</p>
                                </div>` : ''
                            }
                            <div class="flex justify-end">
                                <button id="close-advice" class="px-4 py-2 bg-primary text-white rounded-lg">明白了</button>
                            </div>
                        </div>
                    `;
                    
                    document.getElementById('close-advice').addEventListener('click', function() {
                        document.body.removeChild(modal);
                    });
                });
            });
        });
    };
    
    setupEmergencyHelp();

    // 添加固定目录滚动效果
    const handleTableOfContentsScroll = () => {
        const toc = document.getElementById('table-of-contents');
        if (!toc) return;
        
        // 基于滚动位置调整目录
        window.addEventListener('scroll', () => {
            if (window.scrollY > 300) {
                toc.classList.add('lg:sticky', 'lg:top-24');
            } else {
                toc.classList.remove('lg:sticky', 'lg:top-24');
            }
        });
    };
    
    handleTableOfContentsScroll();

    // 添加风险评估工具交互
    const setupRiskAssessment = () => {
        const checkboxes = document.querySelectorAll('#risk-factors input[type="checkbox"]');
        if (checkboxes.length === 0) return;
        
        checkboxes.forEach(checkbox => {
            checkbox.addEventListener('change', () => {
                // 计算选中的风险因素数量
                const checkedCount = [...checkboxes].filter(box => box.checked).length;
                
                // 获取风险评估显示元素
                const riskDisplay = document.querySelector('#risk-factors .font-medium + ul');
                if (!riskDisplay) return;
                
                // 根据选中数量高亮显示风险等级
                const riskLevels = riskDisplay.querySelectorAll('li');
                riskLevels.forEach(level => {
                    level.classList.remove('font-bold', 'text-primary');
                });
                
                // 设置对应风险等级高亮
                if (checkedCount >= 0 && checkedCount <= 2) {
                    riskLevels[0].classList.add('font-bold', 'text-primary');
                } else if (checkedCount >= 3 && checkedCount <= 5) {
                    riskLevels[1].classList.add('font-bold', 'text-primary');
                } else if (checkedCount >= 6 && checkedCount <= 8) {
                    riskLevels[2].classList.add('font-bold', 'text-primary');
                } else if (checkedCount >= 9) {
                    riskLevels[3].classList.add('font-bold', 'text-primary');
                }
            });
        });
    };
    
    setupRiskAssessment();
});

