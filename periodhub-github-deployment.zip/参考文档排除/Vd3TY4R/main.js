document.addEventListener('DOMContentLoaded', function() {
    // Pain level evaluation (OMITTED as per previous_code structure for this task)

    // Mobile menu toggle
    const mobileMenuButton = document.getElementById('mobile-menu-button');
    const mobileMenuIconOpen = mobileMenuButton ? mobileMenuButton.querySelector('svg:first-child') : null;
    const mobileMenuIconClose = mobileMenuButton ? mobileMenuButton.querySelector('svg:last-child') : null;
    
    let mobileMenuContentElement = document.getElementById('mobile-menu');

    if (mobileMenuButton) {
        // If main.js is supposed to create the menu, this part handles it.
        // Otherwise, it assumes 'mobile-menu' div exists in HTML.
        // Based on common practice and robustness, checking if it exists first or creating.
        // The previous main.js CREATED it. So we stick to that, but update its content.

        if (!document.getElementById('mobile-menu-dynamic-content')) { // Avoid multiple creations
            mobileMenuContentElement = document.createElement('div');
            mobileMenuContentElement.id = 'mobile-menu-dynamic-content'; // Assign an ID to avoid re-creation
            mobileMenuContentElement.className = 'sm:hidden bg-white pb-3 pt-2 hidden'; // Initial state: hidden
            
            // Updated links for mobile menu
            // Active style: "bg-rose-50 border-rose-500 text-rose-700 block pl-3 pr-4 py-2 border-l-4 text-base font-medium"
            // Inactive style: "border-transparent text-gray-500 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-700 block pl-3 pr-4 py-2 border-l-4 text-base font-medium"
            // Assuming index.html is the "Natural Remedies" page, it's the active one.
            mobileMenuContentElement.innerHTML = `
                <div class="pt-2 pb-3 space-y-1 px-2">
                    <a href="index.html" class="border-transparent text-gray-500 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-700 block pl-3 pr-4 py-2 border-l-4 text-base font-medium">首页</a>
                    <a href="index.html" class="bg-rose-50 border-rose-500 text-rose-700 block pl-3 pr-4 py-2 border-l-4 text-base font-medium" aria-current="page">自然疗法</a>
                    <a href="causes-of-dysmenorrhea.html" class="border-transparent text-gray-500 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-700 block pl-3 pr-4 py-2 border-l-4 text-base font-medium">痛经原因</a>
                    <a href="interactive-solutions.html" class="border-transparent text-gray-500 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-700 block pl-3 pr-4 py-2 border-l-4 text-base font-medium">互动解决方案</a>
                </div>
            `;
            // Insert the created mobile menu after the navbar's main content div
            const navMainDiv = document.querySelector('nav > div.max-w-7xl');
            if (navMainDiv && navMainDiv.parentNode) {
                 navMainDiv.parentNode.insertBefore(mobileMenuContentElement, navMainDiv.nextSibling);
            }
        } else {
            mobileMenuContentElement = document.getElementById('mobile-menu-dynamic-content');
        }


        mobileMenuButton.addEventListener('click', function() {
            const isExpanded = mobileMenuButton.getAttribute('aria-expanded') === 'true' || false;
            mobileMenuButton.setAttribute('aria-expanded', !isExpanded);
            mobileMenuContentElement.classList.toggle('hidden');
            if (mobileMenuIconOpen && mobileMenuIconClose) {
                mobileMenuIconOpen.classList.toggle('hidden');
                mobileMenuIconClose.classList.toggle('hidden');
            }
        });
    }

    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();

            const targetId = this.getAttribute('href');
            if (targetId === '#') return; // Skip if href is just "#"

            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                // Calculate offset considering the sticky navigation bar height
                const navHeight = document.querySelector('nav')?.offsetHeight || 0;
                const targetPosition = targetElement.offsetTop - navHeight - 20; // Extra 20px padding

                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });

    // Highlight current section in navigation based on scroll position
    // This part is complex if nav links are not just anchors.
    // For now, keeping the anchor-based highlighting.
    const sections = document.querySelectorAll('section[id]');
    const tocLinks = document.querySelectorAll('.grid a[href^="#"]'); // More specific selector for TOC links

    function highlightCurrentSection() {
        const scrollPosition = window.scrollY + (document.querySelector('nav')?.offsetHeight || 0) + 40; // Offset + buffer

        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.offsetHeight;
            const sectionId = section.getAttribute('id');

            if (scrollPosition >= sectionTop && scrollPosition < sectionTop + sectionHeight) {
                tocLinks.forEach(link => {
                    link.classList.remove('text-rose-800', 'font-semibold'); // Clear active style from all
                    if (link.getAttribute('href') === `#${sectionId}`) {
                        link.classList.add('text-rose-800', 'font-semibold'); // Apply active style
                    }
                });
            }
        });

        // Handle case where no section is active (e.g., top of page)
        let anyLinkActive = false;
        tocLinks.forEach(link => {
            if (link.classList.contains('text-rose-800')) {
                anyLinkActive = true;
            }
        });
        if (!anyLinkActive && tocLinks.length > 0) {
             // Optionally, highlight the first link or no link
        }
    }

    window.addEventListener('scroll', highlightCurrentSection);
    highlightCurrentSection(); // Initial call

    // Interaction tracking (OMITTED as per previous_code structure for this task)
});
