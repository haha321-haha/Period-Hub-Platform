document.addEventListener('DOMContentLoaded', function() {
    // 移动端菜单切换
    const menuButton = document.getElementById('mobile-menu-button');
    const mobileMenu = document.getElementById('mobile-menu');

    if (menuButton && mobileMenu) {
        menuButton.addEventListener('click', function() {
            mobileMenu.classList.toggle('hidden');
        });
    }

    // 平滑滚动到锚点
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            const targetId = this.getAttribute('href');
            if (targetId.length > 1) {
                e.preventDefault();

                const targetElement = document.querySelector(targetId);
                if (targetElement) {
                    const navHeight = document.querySelector('header')?.offsetHeight || 0;
                    const targetPosition = targetElement.getBoundingClientRect().top + window.pageYOffset - navHeight - 20; // 20px padding
                    window.scrollTo({
                        top: targetPosition,
                        behavior: 'smooth'
                    });

                    // 如果是在移动端菜单点击的，关闭菜单
                    if (mobileMenu && !mobileMenu.classList.contains('hidden')) {
                        mobileMenu.classList.add('hidden');
                    }
                }
            }
        });
    });

    // 处理目录激活状态
    const activateTableOfContents = () => {
        // 获取所有文章部分
        const sections = document.querySelectorAll('article[id]');
        // 获取所有目录链接
        const navLinks = document.querySelectorAll('#table-of-contents a');
        
        if (sections.length === 0 || navLinks.length === 0) return;

        // 监听滚动事件
        window.addEventListener('scroll', () => {
            let currentSectionId = '';
            const scrollPosition = window.scrollY;

            // 确定当前滚动位置对应哪个部分
            sections.forEach(section => {
                const sectionTop = section.offsetTop - 150;

                if (scrollPosition >= sectionTop) {
                    currentSectionId = section.getAttribute('id');
                }
            });

            // 更新目录激活状态
            navLinks.forEach(link => {
                link.classList.remove('active');
                const href = link.getAttribute('href').substring(1);
                if (href === currentSectionId) {
                    link.classList.add('active');
                }
            });
        });
    };
    activateTableOfContents();

    // 痛经自评工具
    const setupPainTest = () => {
        const evaluateButton = document.getElementById('evaluate-medical');
        const resultDiv = document.getElementById('medical-test-result');
        const resultText = document.getElementById('medical-result-text');

        if (!evaluateButton || !resultDiv || !resultText) return;

        evaluateButton.addEventListener('click', () => {
            // 获取用户选择
            const intensity = document.querySelector('input[name="intensity"]:checked')?.value;
            const onset = document.querySelector('input[name="onset"]:checked')?.value;
            const severeSymptoms = Array.from(document.querySelectorAll('input[name="severe_symptom"]:checked')).map(input => input.value);
            
            if (!intensity || !onset) {
                alert('请先选择痛经强度和开始时间');
                return;
            }

            // 分析结果
            let advice = '';
            let needConsult = false;

            // 检查是否有严重症状
            if (severeSymptoms.length > 0) {
                advice = '根据您选择的症状（如发热、剧烈呕吐、昏厥或异常出血），建议您尽快咨询医生，这些可能是需要医疗评估的警示信号。';
                needConsult = true;
            } 
            // 根据痛经强度和开始时间评估
            else if (intensity === 'severe') {
                if (onset === 'late') {
                    advice = '重度痛经如果在初潮较晚后开始，可能提示继发性痛经的风险，建议咨询医生排除潜在的妇科问题。';
                    needConsult = true;
                } else {
                    advice = '您的痛经严重程度较高。虽然可能是原发性痛经，但影响日常生活的严重疼痛建议医学评估，以获得有效的疼痛管理方案。';
                    needConsult = true;
                }
            } else if (intensity === 'moderate' && onset === 'late') {
                advice = '中度痛经在初潮较晚后开始，建议咨询医生排除继发性痛经的可能性。';
                needConsult = true;
            } else {
                advice = '基于您提供的信息，您的痛经情况属于常见范围，可能是原发性痛经。建议尝试本文中介绍的自然缓解方法，如热敷、轻度运动和健康饮食习惯等。如症状加重或出现异常，请及时咨询医生。';
                needConsult = false;
            }

            // 显示结果
            resultText.textContent = advice;
            resultDiv.classList.remove('hidden');

            // 添加建议链接
            if (needConsult) {
                resultText.innerHTML += '<br><br>了解更多关于何时需要寻求医疗帮助的信息，请查看<a href="#when-to-seek" class="text-primary hover:underline font-medium">何时需要就医</a>部分。';
            } else {
                resultText.innerHTML += '<br><br>探索更多缓解方法，请查看<a href="#home-care" class="text-primary hover:underline font-medium">家庭护理方法</a>部分。';
            }
        });
    };
    setupPainTest();

    // 处理紧急求助按钮
    const setupEmergencyHelp = () => {
        const emergencyButtons = document.querySelectorAll('.emergency-help-btn');

        emergencyButtons.forEach(button => {
            button.addEventListener('click', function(e) {
                e.preventDefault();

                const modal = document.createElement('div');
                modal.className = 'fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4';

                modal.innerHTML = `
                    <div class="bg-white rounded-lg p-6 max-w-md w-full mx-auto shadow-xl">
                        <div class="flex justify-between items-center mb-4">
                            <h3 class="text-xl font-bold text-primary">紧急痛经求助</h3>
                            <button id="close-modal-btn" class="text-gray-500 hover:text-gray-700">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                                </svg>
                            </button>
                        </div>
                        <div class="mb-4">
                            <p class="mb-2 font-medium">请选择您的紧急情况:</p>
                            <div class="space-y-2 text-sm">
                                <div class="flex items-center"><input type="radio" id="severe-pain-modal" name="emergency" class="mr-2"><label for="severe-pain-modal">痛经非常严重，无法忍受</label></div>
                                <div class="flex items-center"><input type="radio" id="fever-modal" name="emergency" class="mr-2"><label for="fever-modal">痛经伴有发热</label></div>
                                <div class="flex items-center"><input type="radio" id="vomiting-modal" name="emergency" class="mr-2"><label for="vomiting-modal">痛经伴有剧烈呕吐</label></div>
                                <div class="flex items-center"><input type="radio" id="fainting-modal" name="emergency" class="mr-2"><label for="fainting-modal">痛经导致昏厥或将要昏厥</label></div>
                                <div class="flex items-center"><input type="radio" id="abnormal-bleeding-modal" name="emergency" class="mr-2"><label for="abnormal-bleeding-modal">大量或异常出血</label></div>
                                <div class="flex items-center"><input type="radio" id="other-modal" name="emergency" class="mr-2"><label for="other-modal">其他严重情况</label></div>
                            </div>
                        </div>
                        <div class="flex justify-end space-x-3">
                            <button id="cancel-modal" class="px-4 py-2 border border-gray-300 rounded-lg text-sm hover:bg-gray-50">取消</button>
                            <button id="get-help-modal" class="px-4 py-2 bg-primary text-white rounded-lg text-sm hover:bg-accent">获取建议</button>
                        </div>
                    </div>
                `;

                document.body.appendChild(modal);
                document.body.style.overflow = 'hidden'; // 防止背景滚动

                const closeModal = () => {
                    document.body.removeChild(modal);
                    document.body.style.overflow = '';
                };

                modal.querySelector('#close-modal-btn').addEventListener('click', closeModal);
                modal.querySelector('#cancel-modal').addEventListener('click', closeModal);
                
                // 点击模态框外部关闭
                modal.addEventListener('click', function(event) {
                    if (event.target === modal) {
                        closeModal();
                    }
                });

                modal.querySelector('#get-help-modal').addEventListener('click', function() {
                    const selectedOption = modal.querySelector('input[name="emergency"]:checked');
                    if (!selectedOption) {
                        alert('请选择一个选项');
                        return;
                    }

                    let advice = '';
                    let needEmergency = false;
                    let redirectLink = '#when-to-seek';

                    // 根据选择提供建议
                    switch(selectedOption.id) {
                        case 'severe-pain-modal':
                            advice = '您的痛经非常严重，请尝试以下即时缓解方法：1) 使用热水袋或暖宝宝敷于下腹部；2) 服用医生推荐的止痛药；3) 尝试采取胎儿姿势侧卧并休息。如果疼痛持续超过24小时且无法缓解，建议就医。';
                            needEmergency = false;
                            break;
                        case 'fever-modal':
                        case 'vomiting-modal':
                        case 'fainting-modal':
                        case 'abnormal-bleeding-modal':
                        case 'other-modal':
                            advice = '您的症状可能需要紧急医疗评估。请立即告知家长/监护人并尽快就医，或在必要时拨打急救电话。';
                            needEmergency = true;
                            redirectLink = '#when-to-seek';
                            break;
                    }
                    
                    const modalContent = modal.querySelector('.bg-white');
                    modalContent.innerHTML = `
                        <div class="flex justify-between items-center mb-4">
                             <h3 class="text-xl font-bold ${needEmergency ? 'text-red-600' : 'text-primary'}">
                                ${needEmergency ? '重要提示：寻求医疗帮助' : '缓解建议'}
                            </h3>
                            <button id="final-close-modal-btn" class="text-gray-500 hover:text-gray-700">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                                </svg>
                            </button>
                        </div>
                        <p class="mb-6 text-sm">${advice}</p>
                        ${needEmergency ?
                             `<div class="bg-red-50 p-4 rounded-lg mb-4 border border-red-200">
                                 <p class="text-red-600 font-medium text-sm">您的症状需要医疗评估。请勿拖延。</p>
                                 <p class="text-sm mt-2">痛经伴随发热、剧烈呕吐、昏厥或异常出血可能提示更严重的健康问题。</p>
                             </div>` : ''
                        }
                        <div class="flex justify-end">
                            <a href="${redirectLink}" id="advice-action-link" class="px-4 py-2 bg-primary hover:bg-accent text-white rounded-lg text-sm">
                                ${needEmergency ? '了解何时就医' : '查看更多缓解方法'}
                            </a>
                        </div>
                    `;
                    modalContent.querySelector('#final-close-modal-btn').addEventListener('click', closeModal);
                    modalContent.querySelector('#advice-action-link').addEventListener('click', function(e) {
                        closeModal();
                    });
                });
            });
        });
    };
    setupEmergencyHelp();

    // 为表格添加响应式滚动容器
    const enhanceTables = () => {
        const tables = document.querySelectorAll('table');
        
        tables.forEach(table => {
            if (!table.parentElement.classList.contains('overflow-x-auto')) {
                const wrapper = document.createElement('div');
                wrapper.className = 'overflow-x-auto';
                table.parentNode.insertBefore(wrapper, table);
                wrapper.appendChild(table);
            }
        });
    };
    enhanceTables();

    // 添加图片点击放大功能
    const setupImageZoom = () => {
        const contentImages = document.querySelectorAll('article img');
        
        contentImages.forEach(img => {
            // 排除图标和小装饰图片
            if (img.width > 100 || img.height > 100) {
                img.classList.add('cursor-pointer', 'transition-all');
                img.addEventListener('click', function() {
                    const modal = document.createElement('div');
                    modal.className = 'fixed inset-0 bg-black bg-opacity-75 z-50 flex items-center justify-center p-4';
                    
                    const imgClone = this.cloneNode();
                    imgClone.classList.add('max-w-full', 'max-h-[90vh]', 'object-contain');
                    
                    modal.appendChild(imgClone);
                    document.body.appendChild(modal);
                    document.body.style.overflow = 'hidden';
                    
                    modal.addEventListener('click', function() {
                        document.body.removeChild(modal);
                        document.body.style.overflow = '';
                    });
                });
            }
        });
    };
    setupImageZoom();

    // 青少年特色：简单阅读进度指示器
    const setupReadingProgress = () => {
        const articles = document.querySelector('main article');
        
        if (!articles) return;
        
        const progressBar = document.createElement('div');
        progressBar.className = 'fixed bottom-0 left-0 h-1 bg-primary z-40';
        progressBar.style.width = '0%';
        document.body.appendChild(progressBar);
        
        window.addEventListener('scroll', () => {
            const totalHeight = articles.offsetHeight;
            const windowHeight = window.innerHeight;
            const scrolled = window.scrollY;
            
            const scrollable = totalHeight - windowHeight;
            const progressWidth = Math.min((scrolled / scrollable) * 100, 100);
            
            progressBar.style.width = progressWidth + '%';
        });
    };
    setupReadingProgress();
});
