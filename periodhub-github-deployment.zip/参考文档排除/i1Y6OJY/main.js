document.addEventListener('DOMContentLoaded', function() {
    // 移动端菜单切换
    const menuButton = document.querySelector('button.md\\:hidden');
    const mobileMenu = document.getElementById('mobile-menu');

    if (menuButton && mobileMenu) {
        menuButton.addEventListener('click', function() {
            if (mobileMenu.classList.contains('hidden')) {
                mobileMenu.classList.remove('hidden');
            } else {
                mobileMenu.classList.add('hidden');
            }
        });
    }

    // 平滑滚动到锚点 (Modified to only target local anchors)
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            // Check if it's a local anchor and not just #
            const targetId = this.getAttribute('href');
            if (targetId.length > 1 && targetId.startsWith('#')) {
                 e.preventDefault();

                const targetElement = document.querySelector(targetId);
                if (targetElement) {
                    const navHeight = document.querySelector('header')?.offsetHeight || 0;
                    const targetPosition = targetElement.getBoundingClientRect().top + window.pageYOffset - navHeight - 20; // 20px padding
                    window.scrollTo({
                        top: targetPosition,
                        behavior: 'smooth'
                    });

                    // 如果是在移动端菜单点击的，关闭菜单
                    if (mobileMenu && !mobileMenu.classList.contains('hidden')) {
                        mobileMenu.classList.add('hidden');
                    }
                }
            }
        });
    });

    // 痛经类型快速自测功能
    const setupPainTest = () => {
        const submitButton = document.getElementById('test-submit');
        const resultDiv = document.getElementById('test-result');
        const resultText = document.getElementById('result-text');

        if (!submitButton || !resultDiv || !resultText) return;

        submitButton.addEventListener('click', () => {
            // 获取用户选择
            const q1 = document.querySelector('input[name="q1"]:checked');
            const q2 = document.querySelector('input[name="q2"]:checked');
            const q3a = document.getElementById('q3a').checked;
            const q3b = document.getElementById('q3b').checked;
            const q3c = document.getElementById('q3c').checked;
            const q3d = document.getElementById('q3d').checked;

            if (!q1 || !q2) {
                alert('请回答所有问题');
                return;
            }

            // 分析结果
            let result = '';
            let type = '';

            if (q1.id === 'q1a' && q2.id === 'q2a' && !(q3b || q3c || q3d)) {
                type = 'original';
                result = '您的痛经特征与原发性痛经相符。原发性痛经通常在初潮后1-2年开始，疼痛集中在月经开始前后，无其他器质性疾病症状。';
            } else if ((q1.id === 'q1b' || q1.id === 'q1c') || q2.id === 'q2b' || q3b || q3c || q3d) {
                type = 'secondary';
                result = '您的痛经特征提示可能存在继发性痛经。继发性痛经通常在25岁后或生育后出现，疼痛可能持续整个月经期，并伴有性交痛、月经量异常等症状。建议咨询医生进行评估。';
            } else {
                type = 'mixed';
                result = '您的痛经表现特征不典型，可能需要进一步评估以确定类型。建议记录详细症状并咨询医生。';
            }

            resultText.textContent = result;
            resultDiv.classList.remove('hidden');

            if (type === 'original') {
                 resultText.innerHTML += '<br><br>建议：尝试非甾体抗炎药(如布洛芬)、热敷、轻度运动等缓解方法。若疼痛严重影响生活，可考虑口服避孕药等激素治疗。您也可以尝试我们的<a href="interactive-tools.html#relief-planner-tool" class="text-primary hover:underline font-medium">个性化缓解方案工具</a>。';
             } else if (type === 'secondary') {
                 resultText.innerHTML += '<br><br>建议：建议咨询妇科医生，进行盆腔检查和必要的影像学检查，排除子宫内膜异位症等器质性疾病。同时，您可以使用我们的<a href="interactive-tools.html#symptom-assessor-tool" class="text-primary hover:underline font-medium">症状评估工具</a>更详细地记录并分析您的症状，为就医做准备。';
             } else {
                 resultText.innerHTML += '<br><br>建议：建议使用月经记录APP记录痛经模式，并在疼痛严重时及时就医。您也可以访问我们的<a href="interactive-tools.html" class="text-primary hover:underline font-medium">互动解决方案页面</a>，探索更多工具。';
             }
        });
    };

    setupPainTest();

    // 处理紧急求助按钮
    const setupEmergencyHelp = () => {
        const emergencyButtons = document.querySelectorAll('a[class*="emergency-help-btn"]');

        emergencyButtons.forEach(button => {
            button.addEventListener('click', function(e) {
                e.preventDefault();

                const modal = document.createElement('div');
                modal.className = 'fixed inset-0 bg-black bg-opacity-50 z-[100] flex items-center justify-center p-4'; // Increased z-index

                modal.innerHTML = `
                    <div class="bg-white rounded-lg p-6 max-w-md w-full mx-auto shadow-xl">
                        <div class="flex justify-between items-center mb-4">
                            <h3 class="text-xl font-bold text-primary">紧急痛经求助</h3>
                            <button id="close-modal-btn" class="text-gray-500 hover:text-gray-700">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                                </svg>
                            </button>
                        </div>
                        <div class="mb-4">
                            <p class="mb-2 font-medium">请选择您的紧急情况:</p>
                            <div class="space-y-2 text-sm">
                                <div class="flex items-center"><input type="radio" id="severe-pain-modal" name="emergency" class="mr-2"><label for="severe-pain-modal">痛经非常严重，无法忍受</label></div>
                                <div class="flex items-center"><input type="radio" id="fever-modal" name="emergency" class="mr-2"><label for="fever-modal">痛经伴有发热</label></div>
                                <div class="flex items-center"><input type="radio" id="vomiting-modal" name="emergency" class="mr-2"><label for="vomiting-modal">痛经伴有剧烈呕吐</label></div>
                                <div class="flex items-center"><input type="radio" id="fainting-modal" name="emergency" class="mr-2"><label for="fainting-modal">痛经导致昏厥或将要昏厥</label></div>
                                <div class="flex items-center"><input type="radio" id="abnormal-bleeding-modal" name="emergency" class="mr-2"><label for="abnormal-bleeding-modal">大量或异常出血</label></div>
                                <div class="flex items-center"><input type="radio" id="other-modal" name="emergency" class="mr-2"><label for="other-modal">其他严重情况</label></div>
                            </div>
                        </div>
                        <div class="flex justify-end space-x-3">
                            <button id="cancel-modal" class="px-4 py-2 border border-gray-300 rounded-lg text-sm hover:bg-gray-50">取消</button>
                            <button id="get-help-modal" class="px-4 py-2 bg-primary text-white rounded-lg text-sm hover:bg-accent">获取建议</button>
                        </div>
                    </div>
                `;

                document.body.appendChild(modal);
                document.body.style.overflow = 'hidden'; // Prevent background scroll

                const closeModal = () => {
                    document.body.removeChild(modal);
                    document.body.style.overflow = '';
                };

                modal.querySelector('#close-modal-btn').addEventListener('click', closeModal);
                modal.querySelector('#cancel-modal').addEventListener('click', closeModal);
                
                // Click outside modal to close
                modal.addEventListener('click', function(event) {
                    if (event.target === modal) {
                        closeModal();
                    }
                });


                modal.querySelector('#get-help-modal').addEventListener('click', function() {
                    const selectedOption = modal.querySelector('input[name="emergency"]:checked');
                    if (!selectedOption) {
                        alert('请选择一个选项');
                        return;
                    }

                    let advice = '';
                    let needEmergency = false;
                    let redirectLink = '/articles/when-to-seek-doctor'; 

                    switch(selectedOption.id) {
                        case 'severe-pain-modal':
                            advice = '痛经非常严重，尝试热敷和非处方止痛药。若无法缓解，建议尽快就医。';
                            needEmergency = true; 
                            break;
                        case 'fever-modal':
                        case 'vomiting-modal':
                        case 'fainting-modal':
                        case 'abnormal-bleeding-modal':
                        case 'other-modal':
                            advice = '您的症状可能需要紧急医疗评估。';
                            needEmergency = true;
                            redirectLink = '/articles/when-to-seek-doctor#emergency-situations'; 
                            break;
                    }
                    
                    const modalContent = modal.querySelector('.bg-white');
                    modalContent.innerHTML = `
                        <div class="flex justify-between items-center mb-4">
                             <h3 class="text-xl font-bold ${needEmergency ? 'text-red-600' : 'text-primary'}">
                                ${needEmergency ? '重要提示：寻求医疗帮助' : '缓解建议'}
                            </h3>
                            <button id="final-close-modal-btn" class="text-gray-500 hover:text-gray-700">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                                </svg>
                            </button>
                        </div>
                        <p class="mb-6 text-sm">${advice}</p>
                        ${needEmergency ?
                             `<div class="bg-red-50 p-4 rounded-lg mb-4 border border-red-200">
                                 <p class="text-red-600 font-medium text-sm">您的症状建议进行医疗评估。</p>
                                 <p class="text-sm mt-2">请点击下方按钮了解更多关于何时就医的信息。</p>
                             </div>` : ''
                        }
                        <div class="flex justify-end">
                            <a href="${redirectLink}" id="advice-action-link" class="px-4 py-2 bg-primary hover:bg-accent text-white rounded-lg text-sm">
                                ${needEmergency ? '查看何时就医指南' : '好的，知道了'}
                            </a>
                        </div>
                    `;
                    modalContent.querySelector('#final-close-modal-btn').addEventListener('click', closeModal);
                    modalContent.querySelector('#advice-action-link').addEventListener('click', function(e) {
                        // This allows navigation for the link, then closes the modal.
                        // If it's a hash link, special handling might be needed if it's on the same page, but here it's always an article or section.
                        closeModal(); 
                    });
                });
            });
        });
    };
    
    setupEmergencyHelp();

    // Medical quick test logic - This was in previous_code's main.js.
    // Assuming its HTML might be on a different page or section not fully shown.
    // The links inside are updated to point to interactive-tools.html if they were generic.
    const setupMedicalQuickTest = () => {
         const evaluateButton = document.getElementById('evaluate-medical');
         const resultDiv = document.getElementById('medical-test-result');
         const resultText = document.getElementById('medical-result-text');

         if (!evaluateButton || !resultDiv || !resultText) {
            // console.warn("Medical quick test elements not found. Skipping setup.");
            return;
         }

         evaluateButton.addEventListener('click', () => {
             const intensity = document.querySelector('input[name="intensity"]:checked')?.value;
             const onset = document.querySelector('input[name="onset"]:checked')?.value;
             const associatedSymptoms = document.querySelectorAll('#quick-seek-medical-test input[type="checkbox"]:checked');
              const hasSeriousSymptoms = [...associatedSymptoms].some(checkbox =>
                   ['fever', 'vomiting', 'fainting', 'abnormal_bleeding', 'other_pain'].includes(checkbox.value)
              );

             let advice = '';
             let needConsult = false;

             if (!intensity || !onset) {
                 alert('请选择痛经强度和何时开始');
                 return;
             }

             if (hasSeriousSymptoms) {
                 advice = '您的症状（如发热、剧烈呕吐、异常出血或非经期疼痛）可能提示需要医疗评估。建议您尽快咨询医生。';
                 needConsult = true;
             } else if (intensity === 'severe') {
                  if (onset === 'late') {
                      advice = '重度痛经如果在25岁以后或生育后首次出现，可能提示继发性痛经风险。建议咨询医生进行评估。';
                      needConsult = true;
                  } else { 
                      advice = '您的痛经非常严重，虽然可能属于原发性，但影响生活质量。建议咨询医生以获得更有效的疼痛管理方案，并排除继发性原因。';
                       needConsult = true;
                  }
             } else if (intensity === 'moderate' && onset === 'late') {
                  advice = '中度痛经如果在25岁以后或生育后首次出现，建议咨询医生进行评估，排除继发性痛经的可能。';
                  needConsult = true;
             }
             else { 
                  advice = '您的痛经（轻度，或症状不严重且发病早）可能属于原发性痛经。可以通过热敷、非处方止痛药或自然疗法缓解。如果症状加重或出现异常，请咨询医生。';
                  needConsult = false;
             }

             resultText.textContent = advice;
             resultDiv.classList.remove('hidden');

              if (needConsult) {
                  resultText.innerHTML += `<br><br>了解更多关于何时需要寻求医疗帮助的信息，请访问：<a href="/articles/when-to-seek-doctor" class="text-primary hover:underline font-medium">何时就医指南</a>`;
              } else {
                   resultText.innerHTML += `<br><br>探索更多个性化缓解方法，请访问：<a href="interactive-tools.html" class="text-primary hover:underline font-medium">互动解决方案页面</a>`;
              }
         });
    };
    setupMedicalQuickTest();
});
