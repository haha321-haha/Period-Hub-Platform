document.addEventListener('DOMContentLoaded', function () {
    // Mobile menu toggle for interactive-tools.html
    const menuButtonTools = document.getElementById('mobile-menu-button-tools');
    const mobileMenuTools = document.getElementById('mobile-menu-tools');

    if (menuButtonTools && mobileMenuTools) {
        menuButtonTools.addEventListener('click', function () {
            mobileMenuTools.classList.toggle('hidden');
        });
    }
    
    // Emergency help button functionality for interactive-tools.html
    const setupEmergencyHelpTools = () => {
        const emergencyButtonsTools = document.querySelectorAll('.emergency-help-btn-tools');

        emergencyButtonsTools.forEach(button => {
            button.addEventListener('click', function(e) {
                e.preventDefault();

                const modal = document.createElement('div');
                modal.className = 'fixed inset-0 bg-black bg-opacity-50 z-[100] flex items-center justify-center p-4';

                modal.innerHTML = `
                    <div class="bg-white rounded-lg p-6 max-w-md w-full mx-auto shadow-xl">
                        <div class="flex justify-between items-center mb-4">
                            <h3 class="text-xl font-bold text-primary">紧急痛经求助</h3>
                            <button id="close-modal-btn-tools" class="text-gray-500 hover:text-gray-700">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                                </svg>
                            </button>
                        </div>
                        <div class="mb-4">
                            <p class="mb-2 font-medium">请选择您的紧急情况:</p>
                            <div class="space-y-2 text-sm">
                                <div class="flex items-center"><input type="radio" id="severe-pain-modal-tools" name="emergency-tools" class="mr-2"><label for="severe-pain-modal-tools">痛经非常严重，无法忍受</label></div>
                                <div class="flex items-center"><input type="radio" id="fever-modal-tools" name="emergency-tools" class="mr-2"><label for="fever-modal-tools">痛经伴有发热</label></div>
                                <div class="flex items-center"><input type="radio" id="vomiting-modal-tools" name="emergency-tools" class="mr-2"><label for="vomiting-modal-tools">痛经伴有剧烈呕吐</label></div>
                                <div class="flex items-center"><input type="radio" id="fainting-modal-tools" name="emergency-tools" class="mr-2"><label for="fainting-modal-tools">痛经导致昏厥或将要昏厥</label></div>
                                <div class="flex items-center"><input type="radio" id="abnormal-bleeding-modal-tools" name="emergency-tools" class="mr-2"><label for="abnormal-bleeding-modal-tools">大量或异常出血</label></div>
                                <div class="flex items-center"><input type="radio" id="other-modal-tools" name="emergency-tools" class="mr-2"><label for="other-modal-tools">其他严重情况</label></div>
                            </div>
                        </div>
                        <div class="flex justify-end space-x-3">
                            <button id="cancel-modal-tools" class="px-4 py-2 border border-gray-300 rounded-lg text-sm hover:bg-gray-50">取消</button>
                            <button id="get-help-modal-tools" class="px-4 py-2 bg-primary text-white rounded-lg text-sm hover:bg-accent">获取建议</button>
                        </div>
                    </div>
                `;

                document.body.appendChild(modal);
                document.body.style.overflow = 'hidden'; 

                const closeModalTools = () => {
                    document.body.removeChild(modal);
                    document.body.style.overflow = '';
                };

                modal.querySelector('#close-modal-btn-tools').addEventListener('click', closeModalTools);
                modal.querySelector('#cancel-modal-tools').addEventListener('click', closeModalTools);
                
                modal.addEventListener('click', function(event) {
                    if (event.target === modal) {
                        closeModalTools();
                    }
                });

                modal.querySelector('#get-help-modal-tools').addEventListener('click', function() {
                    const selectedOption = modal.querySelector('input[name="emergency-tools"]:checked');
                    if (!selectedOption) {
                        alert('请选择一个选项');
                        return;
                    }

                    let advice = '';
                    let needEmergency = false;
                    let redirectLink = '/articles/when-to-seek-doctor'; 

                    switch(selectedOption.id) {
                        case 'severe-pain-modal-tools':
                            advice = '痛经非常严重，尝试热敷和非处方止痛药。若无法缓解，建议尽快就医。';
                            needEmergency = true; 
                            break;
                        case 'fever-modal-tools':
                        case 'vomiting-modal-tools':
                        case 'fainting-modal-tools':
                        case 'abnormal-bleeding-modal-tools':
                        case 'other-modal-tools':
                            advice = '您的症状可能需要紧急医疗评估。';
                            needEmergency = true;
                            redirectLink = '/articles/when-to-seek-doctor#emergency-situations'; 
                            break;
                    }
                    
                    const modalContent = modal.querySelector('.bg-white');
                    modalContent.innerHTML = `
                        <div class="flex justify-between items-center mb-4">
                             <h3 class="text-xl font-bold ${needEmergency ? 'text-red-600' : 'text-primary'}">
                                ${needEmergency ? '重要提示：寻求医疗帮助' : '缓解建议'}
                            </h3>
                            <button id="final-close-modal-btn-tools" class="text-gray-500 hover:text-gray-700">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                                </svg>
                            </button>
                        </div>
                        <p class="mb-6 text-sm">${advice}</p>
                        ${needEmergency ?
                             `<div class="bg-red-50 p-4 rounded-lg mb-4 border border-red-200">
                                 <p class="text-red-600 font-medium text-sm">您的症状建议进行医疗评估。</p>
                                 <p class="text-sm mt-2">请点击下方按钮了解更多关于何时就医的信息。</p>
                             </div>` : ''
                        }
                        <div class="flex justify-end">
                            <a href="${redirectLink}" id="advice-action-link-tools" class="px-4 py-2 bg-primary hover:bg-accent text-white rounded-lg text-sm">
                                ${needEmergency ? '查看何时就医指南' : '好的，知道了'}
                            </a>
                        </div>
                    `;
                    modalContent.querySelector('#final-close-modal-btn-tools').addEventListener('click', closeModalTools);
                    modalContent.querySelector('#advice-action-link-tools').addEventListener('click', function(e) {
                        closeModalTools(); 
                    });
                });
            });
        });
    };
    setupEmergencyHelpTools();


    // Symptom Assessor
    const painIntensitySlider = document.getElementById('pain-intensity');
    const painIntensityValue = document.getElementById('pain-intensity-value');
    const getAssessmentBtn = document.getElementById('get-assessment-btn');
    const assessmentResultDiv = document.getElementById('assessment-result');
    const assessmentResultP = assessmentResultDiv.querySelector('p');

    if (painIntensitySlider && painIntensityValue) {
        painIntensitySlider.addEventListener('input', () => {
            painIntensityValue.textContent = painIntensitySlider.value;
        });
    }

    if (getAssessmentBtn) {
        getAssessmentBtn.addEventListener('click', () => {
            const intensity = parseInt(painIntensitySlider.value);
            const symptoms = Array.from(document.querySelectorAll('#symptom-assessor-form input[type="checkbox"]:checked'))
                                .map(cb => cb.labels[0].textContent);
            const timing = document.getElementById('pain-timing').value;
            const onsetAge = document.getElementById('pain-onset-age').value;

            let assessment = `根据您的输入：\n`;
            assessment += `- 疼痛强度: ${intensity}/10\n`;
            assessment += `- 主要症状: ${symptoms.length > 0 ? symptoms.join(', ') : '未选择其他症状'}\n`;
            assessment += `- 疼痛开始时间: ${document.querySelector(`#pain-timing option[value="${timing}"]`).textContent}\n`;
            assessment += `- 痛经通常开始年龄: ${document.querySelector(`#pain-onset-age option[value="${onsetAge}"]`).textContent}\n\n`;

            if (intensity >= 7) {
                assessment += "您的疼痛强度较高。";
            } else if (intensity >= 4) {
                assessment += "您的疼痛强度为中等。";
            } else {
                assessment += "您的疼痛强度较低。";
            }

            if (symptoms.includes('腰背痛') && intensity > 5) {
                assessment += "伴随腰背痛可能提示盆腔问题。";
            }
             if ( (onsetAge === 'late_adult' || onsetAge === 'post_childbirth') && intensity > 5) {
                assessment += " 25岁以后或生育后出现的较强痛经，建议关注是否为继发性痛经的可能。";
            } else if (onsetAge === 'teen' && symptoms.length <= 2 && !symptoms.some(s => ['恶心/呕吐', '情绪波动'].includes(s)) ) {
                assessment += " 年轻时开始且症状相对单一的痛经，较多考虑原发性痛经。";
            }


            assessment += "\n\n请注意：这仅为初步评估，不能替代专业医疗诊断。如果疼痛严重或有疑虑，请咨询医生。";
            
            assessmentResultP.innerText = assessment;
            assessmentResultDiv.classList.remove('hidden');
        });
    }

    // Personalized Relief Plan Recommender
    const dataSourceRadios = document.querySelectorAll('input[name="data-source"]');
    const directInputSection = document.getElementById('direct-input-section');
    const getReliefPlanBtn = document.getElementById('get-relief-plan-btn');
    const reliefPlanResultDiv = document.getElementById('relief-plan-result');
    const reliefPlanResultContent = reliefPlanResultDiv.querySelector('div');

    dataSourceRadios.forEach(radio => {
        radio.addEventListener('change', () => {
            if (radio.value === 'direct') {
                directInputSection.classList.remove('hidden');
            } else {
                directInputSection.classList.add('hidden');
            }
        });
    });

    if (getReliefPlanBtn) {
        getReliefPlanBtn.addEventListener('click', () => {
            let painLevel, mainSymptomsList, preferredMethodsList;
            const additionalInfo = document.getElementById('additional-info').value.trim();

            if (document.getElementById('source-assessor').checked) {
                painLevel = parseInt(painIntensitySlider.value);
                mainSymptomsList = Array.from(document.querySelectorAll('#symptom-assessor-form input[type="checkbox"]:checked'))
                                     .map(cb => cb.labels[0].textContent);
                // For preferred methods, if using assessor data, we could add a new section or assume general preferences
                preferredMethodsList = Array.from(document.querySelectorAll('#relief-planner-form input[type="checkbox"]:checked'))
                                     .map(cb => cb.labels[0].textContent.split(' (')[0]); // Get only the name part
            } else {
                painLevel = parseInt(document.getElementById('direct-pain-intensity').value);
                const mainSymptomText = document.getElementById('direct-main-symptom').value.trim();
                mainSymptomsList = mainSymptomText ? mainSymptomText.split(/,|，|\s+/).filter(s => s) : [];
                preferredMethodsList = Array.from(document.querySelectorAll('#direct-input-section input[type="checkbox"]:checked'))
                                     .map(cb => cb.labels[0].textContent.split(' (')[0]);
            }
            
            let plan = "";

            if (isNaN(painLevel)) {
                alert("请输入有效的疼痛强度。");
                return;
            }

            plan += `<p><strong>根据您的信息：</strong></p>`;
            plan += `<ul class="list-disc list-inside mb-3">`;
            plan += `<li>疼痛强度: ${painLevel}/10</li>`;
            plan += `<li>主要症状: ${mainSymptomsList.length > 0 ? mainSymptomsList.join(', ') : '未提供'}</li>`;
            plan += `<li>偏好缓解方式: ${preferredMethodsList.length > 0 ? preferredMethodsList.join(', ') : '未提供'}</li>`;
            if (additionalInfo) {
                plan += `<li>补充信息: ${additionalInfo}</li>`;
            }
            plan += `</ul>`;
            
            plan += `<p class="font-semibold text-primary mb-2">初步缓解建议：</p><ul class="list-disc list-inside space-y-1">`;

            // General advice based on pain level
            if (painLevel >= 7) {
                plan += "<li>疼痛剧烈，建议优先考虑医生咨询。可尝试非甾体抗炎药（如布洛芬、萘普生），请按说明书或医嘱使用。</li>";
                plan += "<li>严重疼痛时，休息非常重要。尝试舒适的卧姿。</li>";
            } else if (painLevel >= 4) {
                plan += "<li>中度疼痛，可尝试非处方止痛药。热敷（热水袋或暖宝宝）于小腹部可能有效缓解。</li>";
            } else {
                plan += "<li>轻度疼痛，通常可以通过非药物方法缓解。</li>";
            }

            // Symptom-specific advice
            if (mainSymptomsList.includes('痉挛/绞痛') || mainSymptomsList.some(s => s.toLowerCase().includes('cramp'))) {
                plan += "<li>针对痉挛/绞痛：热敷是常用且有效的方法。可尝试饮用温热的姜茶或洋甘菊茶。</li>";
            }
            if (mainSymptomsList.includes('腹胀') || mainSymptomsList.some(s => s.toLowerCase().includes('bloat'))) {
                plan += "<li>针对腹胀：避免产气食物（如豆类、某些蔬菜），尝试饮用薄荷茶，进行轻度腹部按摩。</li>";
            }
            if (mainSymptomsList.includes('腰背痛') || mainSymptomsList.some(s => s.toLowerCase().includes('backache'))) {
                plan += "<li>针对腰背痛：适当的拉伸运动，如猫牛式瑜伽。局部热敷。</li>";
            }
             if (mainSymptomsList.includes('情绪波动') || mainSymptomsList.some(s => s.toLowerCase().includes('mood'))) {
                plan += "<li>针对情绪波动：保证充足睡眠，尝试冥想或深呼吸练习。与信任的人交流。</li>";
            }


            // Preferred methods
            if (preferredMethodsList.includes('自然疗法')) {
                plan += "<li>您偏好自然疗法：可考虑热敷、饮用草药茶（如姜茶、覆盆子叶茶）、香薰（薰衣草、洋甘菊精油）。</li>";
            }
            if (preferredMethodsList.includes('药物')) {
                 if (painLevel < 4 && !additionalInfo.toLowerCase().includes("nsaid无效") && !additionalInfo.toLowerCase().includes("止痛药无效")) {
                    plan += "<li>您选择了药物偏好：对于轻度疼痛，若其他方法无效，可考虑非处方止痛药，但优先尝试非药物方法。</li>";
                 } else if (painLevel >=4) {
                    plan += "<li>您选择了药物偏好：对于中重度疼痛，非甾体抗炎药 (NSAIDs) 是常用选择，如布洛芬。请在月经来潮前或刚开始时服用效果更佳。</li>";
                 }
            }
            if (preferredMethodsList.includes('轻度运动')) {
                plan += "<li>您偏好轻度运动：经期适度的运动如散步、瑜伽（避免倒立和剧烈腹部扭转体式）、太极有助于缓解不适。</li>";
            }
             if (preferredMethodsList.includes('饮食调整')) {
                plan += "<li>您偏好饮食调整：经期注意清淡饮食，增加富含Omega-3（如鱼油）、镁（如深绿色蔬菜、坚果）和维生素B群的食物。减少咖啡因、高糖和加工食品摄入。</li>";
            }
            
            if (additionalInfo.toLowerCase().includes("备孕")) {
                plan += "<li class='text-red-600 font-semibold'>重要：由于您提到正在备孕，请在医生指导下使用任何药物，特别是NSAIDs类止痛药，因其可能影响排卵。</li>";
            }


            plan += "</ul>";
            plan += "<p class='mt-4 text-xs text-gray-500'>以上建议仅为初步参考，具体情况请结合自身条件并在必要时咨询医生。</p>";

            reliefPlanResultContent.innerHTML = plan;
            reliefPlanResultDiv.classList.remove('hidden');
        });
    }
});
