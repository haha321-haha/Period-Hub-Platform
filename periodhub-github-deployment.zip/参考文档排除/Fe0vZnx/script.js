document.addEventListener('DOMContentLoaded', function() {
    // Tab functionality for pain levels
    const tabButtons = document.querySelectorAll('.tab-button');
    const painContent = document.getElementById('painContent');
    
    // Initialize with mild pain content selected
    showPainLevelContent('mild');
    
    // Add click event listeners to tab buttons
    tabButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Remove active class from all buttons
            tabButtons.forEach(btn => btn.classList.remove('active'));
            
            // Add active class to clicked button
            this.classList.add('active');
            
            // Show corresponding content
            const painLevel = this.getAttribute('data-level');
            showPainLevelContent(painLevel);
        });
    });
    
    // Function to show pain level content
    function showPainLevelContent(level) {
        // Get the appropriate data for the selected level
        const symptomData = symptoms[level];
        const solutionData = solutions[level];
        
        // Create HTML content
        let contentHTML = `
            <div class="pain-level-box ${level}-pain bg-white p-6 rounded-xl shadow-md mb-8">
                <h3 class="text-2xl font-bold mb-4">${symptomData.title}</h3>
                <div class="text-gray-700 mb-5">
                    <p class="mb-3">${symptomData.description}</p>
                </div>
                
                <h4 class="font-semibold text-xl mb-3">症状特征：</h4>
                <ul class="list-disc pl-5 text-gray-700 mb-5 space-y-2">
                    ${symptomData.characteristics.map(char => `<li>${char}</li>`).join('')}
                </ul>
                
                <div class="mt-4">
                    <h4 class="font-semibold text-xl mb-3">影响日常生活程度：</h4>
                    <p class="text-gray-700">${symptomData.impact}</p>
                </div>
            </div>
            
            <h3 class="text-2xl font-bold mb-6">解决方案</h3>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                ${solutionData.map(solution => `
                    <div class="solution-card bg-white rounded-xl shadow-md overflow-hidden">
                        <img src="${solution.image}" alt="${solution.title}" class="solution-image">
                        <div class="p-5">
                            <h4 class="font-semibold text-lg mb-2">${solution.title}</h4>
                            <p class="text-gray-600 text-sm mb-3">${solution.description}</p>
                            <div>
                                <h5 class="font-medium text-sm text-gray-700 mb-1">具体方法：</h5>
                                <ul class="list-disc pl-5 text-gray-600 text-sm space-y-1">
                                    ${solution.methods.map(method => `<li>${method}</li>`).join('')}
                                </ul>
                            </div>
                        </div>
                    </div>
                `).join('')}
            </div>
            
            <div class="bg-gray-50 p-6 rounded-xl border border-gray-200">
                <h3 class="font-semibold text-xl mb-3">医学研究依据</h3>
                <p class="text-gray-700 mb-4">${solutionData[0].research}</p>
                <p class="text-sm text-gray-500 italic">注：以上推荐基于医学研究，但个体差异可能导致效果不同。请根据自身情况选择合适的方法，必要时咨询医疗专业人士。</p>
            </div>
        `;
        
        // Update the content
        painContent.innerHTML = contentHTML;
    }
    
    // FAQ Accordion functionality
    const faqButtons = document.querySelectorAll('.faq-button');
    faqButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Toggle active class
            this.classList.toggle('active');
            
            // Get the answer panel
            const answer = this.nextElementSibling;
            
            // Toggle visibility
            if (answer.style.display === 'block') {
                answer.style.display = 'none';
            } else {
                answer.style.display = 'block';
            }
        });
    });
});
