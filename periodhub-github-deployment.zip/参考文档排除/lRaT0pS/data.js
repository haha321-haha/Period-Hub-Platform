export const scenes = [
    {
        id: 1,
        title: "场景1：开场 - 表现痛经的不适感",
        videoUrl: "https://v3.fal.media/files/monkey/OMrBMAEeA1my97zJzH64q_output.mp4",
        narration: "很多女性每个月都会经历痛经，那种痉挛、疼痛的感觉让人非常不适。"
    },
    {
        id: 2,
        title: "场景2：解释痛经原因 - 前列腺素",
        videoUrl: "https://v3.fal.media/files/panda/DJlINSBKErKOTTRW4scwG_output.mp4",
        narration: "月经期间，子宫内膜会释放一种叫做“前列腺素”的物质。前列腺素会引起子宫肌肉剧烈收缩，导致疼痛。"
    },
    {
        id: 3,
        title: "场景3：引出NSAIDs",
        videoUrl: "https://v3.fal.media/files/monkey/sRVoOWjzmaoyzF7cure1m_output.mp4",
        narration: "而非甾体抗炎药，简称NSAID，是缓解痛经的常用药物。它们能从源头减少前列腺素的产生。"
    },
    {
        id: 4,
        title: "场景4：药物服用",
        videoUrl: "https://v3.fal.media/files/lion/O4Ys7oYqfMg3M0jR80mhw_output.mp4",
        narration: "当您服下NSAID药片后，它会进入消化系统。"
    },
    {
        id: 5,
        title: "场景5：吸收进入血液",
        videoUrl: "https://v3.fal.media/files/elephant/ejMBtuanCnJ9v_RH-3gXc_output.mp4",
        narration: "然后通过消化道被吸收到血液里，随着血液流向全身。"
    },
    {
        id: 6,
        title: "场景6：分布到作用部位",
        videoUrl: "https://v3.fal.media/files/lion/_wrFzYC89XCXhT08_ldCQ_output.mp4",
        narration: "药物分子随着血液循环，最终抵达引起疼痛的部位——比如您的子宫周围。"
    },
    {
        id: 7,
        title: "场景7：作用机制 - 抑制COX酶",
        videoUrl: "https://v3.fal.media/files/zebra/-3fM_hp6Ze7ceOdKospQ-_output.mp4",
        narration: "在这里，NSAID药物找到了产生前列腺素的关键“工厂”——环氧合酶，并抑制了它的活性。"
    },
    {
        id: 8,
        title: "场景8：减少前列腺素",
        videoUrl: "https://v3.fal.media/files/koala/-0hQKGQ9lIMGoyG_jRw2H_output.mp4",
        narration: "环氧合酶的工作被打断，前列腺素的合成量就大大降低了。"
    },
    {
        id: 9,
        title: "场景9：缓解疼痛",
        videoUrl: "https://v3.fal.media/files/kangaroo/J_GjsJknvPItBAuyBk3dl_output.mp4",
        narration: "前列腺素少了，子宫肌肉的过度收缩得到缓解，痛经的疼痛也就减轻了。"
    },
    {
        id: 10,
        title: "场景10：药物代谢与排出",
        videoUrl: "https://v3.fal.media/files/tiger/mUgtr0XZ7ARjBOQ3RDRAI_output.mp4",
        narration: "药物在体内完成使命后，会主要在肝脏进行代谢，然后通过肾脏随尿液排出体外。这个过程就是为什么药物需要一定时间才能起效，以及药效持续时间的原因。"
    },
    {
        id: 11,
        title: "场景11：总结",
        videoUrl: "https://v3.fal.media/files/rabbit/KJPkRFGUjqZpiQcIxWghk_output.mp4",
        narration: "通过抑制前列腺素，NSAID能有效缓解痛经，帮助您更好地度过经期。记住，请务必按照医生或药师的指导正确用药。"
    }
];
