import { scenes } from './data.js';

document.addEventListener('DOMContentLoaded', () => {
    lucide.createIcons();

    const videoPlayer = document.getElementById('animationPlayer');
    const sceneTitleElement = document.getElementById('sceneTitle');
    const narrationTextElement = document.getElementById('narrationText');
    const prevButton = document.getElementById('prevButton');
    const nextButton = document.getElementById('nextButton');
    const sceneIndicatorElement = document.getElementById('sceneIndicator');

    let currentSceneIndex = 0;

    function loadScene(index) {
        if (index < 0 || index >= scenes.length) {
            console.error('Scene index out of bounds:', index);
            return;
        }

        currentSceneIndex = index;
        const scene = scenes[currentSceneIndex];

        videoPlayer.src = scene.videoUrl;
        sceneTitleElement.textContent = scene.title;
        narrationTextElement.textContent = scene.narration;
        sceneIndicatorElement.textContent = `场景 ${scene.id} / ${scenes.length}`;
        




        videoPlayer.play().catch(error => {
            console.warn("Autoplay prevented:", error);


        });

        updateNavigationButtons();
    }

    function updateNavigationButtons() {
        prevButton.disabled = currentSceneIndex === 0;


    }

    function playNextScene() {
        currentSceneIndex++;
        if (currentSceneIndex >= scenes.length) {
            currentSceneIndex = 0; // Loop back to the first scene
        }
        loadScene(currentSceneIndex);
    }

    function playPrevScene() {
        currentSceneIndex--;
        if (currentSceneIndex < 0) {
            currentSceneIndex = scenes.length - 1; // Loop back to the last scene from beginning
        }
        loadScene(currentSceneIndex);
    }

    videoPlayer.addEventListener('ended', () => {
        playNextScene();
    });

    videoPlayer.addEventListener('error', (e) => {
        console.error('Video error:', e);
        narrationTextElement.textContent = '抱歉，视频加载失败。请检查您的网络连接或稍后再试。';
        sceneTitleElement.textContent = '视频加载错误';
    });
    
    prevButton.addEventListener('click', () => {
        playPrevScene();
    });

    nextButton.addEventListener('click', () => {
        playNextScene();
    });


    if (scenes.length > 0) {
        loadScene(0);
    } else {
        sceneTitleElement.textContent = "没有可播放的场景";
        narrationTextElement.textContent = "请检查数据配置。";
        prevButton.disabled = true;
        nextButton.disabled = true;
        sceneIndicatorElement.textContent = "场景 0 / 0";
    }
});
